use supermercadoproyecto;

SELECT * FROM Detalle_Ventas;
SELECT * FROM inventario;
SELECT * FROM productos;
SELECT * FROM ventas;

-- SET FOREIGN_KEY_CHECKS = 0;
-- SET FOREIGN_KEY_CHECKS = 1;
INSERT INTO Detalle_Ventas (id_venta, id_producto, cantidad, precio_unitario) VALUES
(56, 56, 2, 2.50);

UPDATE Productos SET precio = 1.80
WHERE id_producto = 1;


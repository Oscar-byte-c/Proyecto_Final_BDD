-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: supermercadoProyecto
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`id_categoria`),
  CONSTRAINT `categorias_chk_1` CHECK ((`nombre` <> _utf8mb4''))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Lacteos','Productos derivados de la leche y alternativas vegetales'),(2,'Carnes','Carnes frescas de res, pollo y cerdo'),(3,'Bebidas','Bebidas no alcoholicas y energizantes'),(4,'Panaderia','Panes frescos, pasteles y reposteria'),(5,'Frutas y Verduras','Frutas y verduras frescas de temporada'),(6,'Cereales','Cereales para desayuno y granos enteros'),(7,'Enlatados','Conservas y alimentos enlatados'),(8,'Limpieza','Productos de limpieza para hogar y ropa'),(9,'Cuidado Personal','Productos de higiene personal y cosmeticos'),(10,'Congelados','Alimentos congelados y precocidos'),(11,'Snacks','Aperitivos salados y golosinas'),(12,'Bebidas Alcoholicas','Vinos, cervezas y licores'),(13,'Pescados','Pescados y mariscos frescos'),(14,'Condimentos','Especias, salsas y condimentos'),(15,'Dulces','Chocolates, caramelos y postres'),(16,'Lacteos Veganos','Alternativas vegetales a lacteos'),(17,'Pan sin Gluten','Panes para dietas especiales'),(18,'Bebidas Energeticas','Bebidas energizantes y deportivas'),(19,'Mascotas','Alimentos y accesorios para mascotas'),(20,'Hogar','Articulos para el hogar como toallas y utensilios'),(21,'Frutos Secos','Nueces, almendras y semillas'),(22,'Pastas','Pastas alimenticias secas y frescas'),(23,'Aceites','Aceites comestibles para cocina'),(24,'Salsas','Salsas y aderezos para comidas'),(25,'Postres','Postres preparados y listos para consumir');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varbinary(255) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `es_frecuente` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_cliente`),
  KEY `idx_nombre_clientes` (`nombre`),
  CONSTRAINT `clientes_chk_1` CHECK ((`nombre` <> _utf8mb4''))
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Roberto Silva Gomez',_binary '��\�EN\�3\�\��\�o{Վ��㾁��_S\�\�-���','+593-9-98765416',0),(2,'Carmen Ramirez Vega',_binary '�oU-PE\�m�����\0�	(8v�F��32x�k','+593-9-98765417',1),(3,'Gabriel Luna Castro',_binary '�s\�\0`�\�\�)ױ\�\�\�\�u\�g�\0�2�Ou)���','+593-9-98765418',0),(4,'Valeria Rojas Perez',_binary 'o	\�n��A`��7�-K��㾁��_S\�\�-���','+593-9-98765419',1),(5,'Daniel Cruz Martinez',_binary '�\�^j\�]��\�\��\�\�r\�*��*Q*F@^�4','+593-9-98765420',0),(6,'Marina Flores Torres',_binary 'o�4>��O%6\�\��Y+�9��㾁��_S\�\�-���','+593-9-98765421',1),(7,'Hector Gomez Salazar',_binary '�ޛy�$��jJ���Ɖ\�\�u\�g�\0�2�Ou)���','+593-9-98765422',0),(8,'Natalia Vega Diaz',_binary '\�\�@-B3\"�/7�m��\�&\�\�u\�g�\0�2�Ou)���','+593-9-98765423',1),(9,'Felipe Castro Ruiz',_binary 'XM�P�\����^�縍㾁��_S\�\�-���','+593-9-98765424',0),(10,'Santiago Rivas Morales',_binary 'KiP��\�AAֶ\�4�ڴ��	(8v�F��32x�k','+593-9-98765425',1),(11,'Camila Torres Lopez',_binary 'R3�\�>N�=�\�r�]�\���㾁��_S\�\�-���','+593-9-98765426',1),(12,'Lucas Gomez Ruiz',_binary '\�\�\rD\\�\'��z<�����\�r\�*��*Q*F@^�4','+593-9-98765427',0),(13,'Valentina Salazar Diaz',_binary '#1h\��\�\�ȣ6 qo�l��\�y��\�\�','+593-9-98765428',1),(14,'Mateo Vargas Perez',_binary 'E{4�=���\����\�\�\�u\�g�\0�2�Ou)���','+593-9-98765429',0),(15,'Isabella Diaz Martinez',_binary '>��#�#����\�Y�̸�㾁��_S\�\�-���','+593-9-98765430',1),(16,'Santiago Morales Torres',_binary '�\�\"�u� ,\�k\�\"����6�ܰ3\�\�b�','+593-9-98765431',0),(17,'Emma Romero Diaz',_binary '\�{��\�OwU�3�!\Z\'�\�r\�*��*Q*F@^�4','+593-9-98765432',1),(18,'Tomas Castro Sanchez',_binary 'uz�\�1Ҝ�\�yL/B\�x\�\�u\�g�\0�2�Ou)���','+593-9-98765433',0),(19,'Sofia Ortiz Morales',_binary '\"\�L�5\�\�Z\�{I�q�1\�\�u\�g�\0�2�Ou)���','+593-9-98765434',1),(20,'Benjamin Silva Romero',_binary '\�n\�sb,\�hZ\�I[��	(8v�F��32x�k','+593-9-98765435',0),(21,'Mia Castro Ramirez',_binary 'K\�ɾ.\�2\�yj`\�\�w>\�\�\�Xih� \0\�M�','+593-9-98765436',1),(22,'Sebastian Luna Vargas',_binary '�\�M}y&e4}=z7t�2�	(8v�F��32x�k','+593-9-98765437',0),(23,'Lucia Rojas Herrera',_binary '\�\�V\�ѩ��S���߬�x\�r\�*��*Q*F@^�4','+593-9-98765438',1),(24,'Martin Cruz Mendoza',_binary '���7��T݄8�Rk�\�r\�*��*Q*F@^�4','+593-9-98765439',0),(25,'Julieta Flores Ortiz',_binary '��\�\�X9sns\�ZD휊	(8v�F��32x�k','+593-9-98765440',1),(26,'Nicolas Gomez Silva',_binary '��[\�j��PB�Bo��㾁��_S\�\�-���','+593-9-98765441',0),(27,'Catalina Vega Ramirez',_binary 'f�ӣ�\nߵ\�\�\�1?;���㾁��_S\�\�-���','+593-9-98765442',1),(28,'Juan Luna Castro',_binary '����8\�)\�ҡ�	�㬊\�~0vaA�[x�','+593-9-98765443',0),(29,'Valeria Perez Rojas',_binary '\�Y\�*e7�?\��\�\�r��	(8v�F��32x�k','+593-9-98765444',1),(30,'Diego Martinez Cruz',_binary '��\�\�\�[H��\�\�[�\�\��uf\�˷}-!\�}','+593-9-98765445',0),(31,'Martina Torres Flores',_binary 'z_\�C,�iÝ��	(8v�F��32x�k','+593-9-98765446',1),(32,'Joaquin Salazar Gomez',_binary 'AMU̠k f�k\�j\�|�w\��uf\�˷}-!\�}','+593-9-98765447',0),(33,'Clara Diaz Vega',_binary 'F2��\�Y�|\�\�&	�_\�\�\�Xih� \0\�M�','+593-9-98765448',1),(34,'Emiliano Ruiz Castro',_binary 'E�\�4\\jEV$0\Z\�\��P���㾁��_S\�\�-���','+593-9-98765449',0),(35,'Antonia Morales Rivas',_binary '\Zuߧ\�InX�c\�ó{\��uf\�˷}-!\�}','+593-9-98765450',1),(36,'Ana Lopez Torres',_binary 'MW�\�[˙��\�Dy���\�~0vaA�[x�','+593-9-98765401',1),(37,'Carlos Ruiz Gomez',_binary '\���>)7\�\Z���x��L\�r\�*��*Q*F@^�4','+593-9-98765402',0),(38,'Maria Gomez Salazar',_binary '�\��؎\�\�\�W	TYSS\�r\�*��*Q*F@^�4','+593-9-98765403',1),(39,'Juan Perez Vargas',_binary 'GةX�\�2T\Z����\�\�\�Xih� \0\�M�','+593-9-98765404',0),(40,'Laura Martinez Diaz',_binary '�d\���G��;}�\��s�	(8v�F��32x�k','+593-9-98765405',1),(41,'Diego Torres Morales',_binary '���\�զZ\�#�\�~y\�,�\�\�u\�g�\0�2�Ou)���','+593-9-98765406',0),(42,'Sofia Diaz Romero',_binary 'u�\�\�#���B9�ga9�\�\�\�Xih� \0\�M�','+593-9-98765407',1),(43,'Pedro Sanchez Castro',_binary 'O\�\�Y�Uϻ���7���ٸ�㾁��_S\�\�-���','+593-9-98765408',0),(44,'Clara Morales Ortiz',_binary 'y7/\�\�\�`�M�\�e�Aq\'��㾁��_S\�\�-���','+593-9-98765409',1),(45,'Javier Romero Silva',_binary '\�\�;\��9�Y8��\�\�ʸ�㾁��_S\�\�-���','+593-9-98765410',0),(46,'Elena Castro Ramirez',_binary '�\��\��\�c\�La,0f\�\�u\�g�\0�2�Ou)���','+593-9-98765411',1),(47,'Miguel Vargas Luna',_binary '�\�\�\�\�͛\�X\�!��\����㾁��_S\�\�-���','+593-9-98765412',0),(48,'Paula Herrera Rojas',_binary '\� ;>\�0�^�{.i��㾁��_S\�\�-���','+593-9-98765413',1),(49,'Andres Mendoza Cruz',_binary '���E��O\�T\����	(8v�F��32x�k','+593-9-98765414',0),(50,'Lucia Ortiz Flores',_binary '~\�T\n��$)Ւ�\�q<�\�r\�*��*Q*F@^�4','+593-9-98765415',1),(51,'Roberto Silva Gomez',_binary '��\�EN\�3\�\��\�o{Վ��㾁��_S\�\�-���','+593-9-98765416',0),(52,'Carmen Ramirez Vega',_binary '�oU-PE\�m�����\0�	(8v�F��32x�k','+593-9-98765417',1),(53,'Gabriel Luna Castro',_binary '�s\�\0`�\�\�)ױ\�\�\�\�u\�g�\0�2�Ou)���','+593-9-98765418',0),(54,'Valeria Rojas Perez',_binary 'o	\�n��A`��7�-K��㾁��_S\�\�-���','+593-9-98765419',1),(55,'Daniel Cruz Martinez',_binary '�\�^j\�]��\�\��\�\�r\�*��*Q*F@^�4','+593-9-98765420',0),(56,'Marina Flores Torres',_binary 'o�4>��O%6\�\��Y+�9��㾁��_S\�\�-���','+593-9-98765421',1),(57,'Hector Gomez Salazar',_binary '�ޛy�$��jJ���Ɖ\�\�u\�g�\0�2�Ou)���','+593-9-98765422',0),(58,'Natalia Vega Diaz',_binary '\�\�@-B3\"�/7�m��\�&\�\�u\�g�\0�2�Ou)���','+593-9-98765423',1),(59,'Felipe Castro Ruiz',_binary 'XM�P�\����^�縍㾁��_S\�\�-���','+593-9-98765424',0),(60,'Santiago Rivas Morales',_binary 'KiP��\�AAֶ\�4�ڴ��	(8v�F��32x�k','+593-9-98765425',1),(61,'Camila Torres Lopez',_binary 'R3�\�>N�=�\�r�]�\���㾁��_S\�\�-���','+593-9-98765426',1),(62,'Lucas Gomez Ruiz',_binary '\�\�\rD\\�\'��z<�����\�r\�*��*Q*F@^�4','+593-9-98765427',0),(63,'Valentina Salazar Diaz',_binary '#1h\��\�\�ȣ6 qo�l��\�y��\�\�','+593-9-98765428',1),(64,'Mateo Vargas Perez',_binary 'E{4�=���\����\�\�\�u\�g�\0�2�Ou)���','+593-9-98765429',0),(65,'Isabella Diaz Martinez',_binary '>��#�#����\�Y�̸�㾁��_S\�\�-���','+593-9-98765430',1),(66,'Santiago Morales Torres',_binary '�\�\"�u� ,\�k\�\"����6�ܰ3\�\�b�','+593-9-98765431',0),(67,'Emma Romero Diaz',_binary '\�{��\�OwU�3�!\Z\'�\�r\�*��*Q*F@^�4','+593-9-98765432',1),(68,'Tomas Castro Sanchez',_binary 'uz�\�1Ҝ�\�yL/B\�x\�\�u\�g�\0�2�Ou)���','+593-9-98765433',0),(69,'Sofia Ortiz Morales',_binary '\"\�L�5\�\�Z\�{I�q�1\�\�u\�g�\0�2�Ou)���','+593-9-98765434',1),(70,'Benjamin Silva Romero',_binary '\�n\�sb,\�hZ\�I[��	(8v�F��32x�k','+593-9-98765435',0),(71,'Mia Castro Ramirez',_binary 'K\�ɾ.\�2\�yj`\�\�w>\�\�\�Xih� \0\�M�','+593-9-98765436',1),(72,'Sebastian Luna Vargas',_binary '�\�M}y&e4}=z7t�2�	(8v�F��32x�k','+593-9-98765437',0),(73,'Lucia Rojas Herrera',_binary '\�\�V\�ѩ��S���߬�x\�r\�*��*Q*F@^�4','+593-9-98765438',1),(74,'Martin Cruz Mendoza',_binary '���7��T݄8�Rk�\�r\�*��*Q*F@^�4','+593-9-98765439',0),(75,'Julieta Flores Ortiz',_binary '��\�\�X9sns\�ZD휊	(8v�F��32x�k','+593-9-98765440',1),(76,'Nicolas Gomez Silva',_binary '��[\�j��PB�Bo��㾁��_S\�\�-���','+593-9-98765441',0),(77,'Catalina Vega Ramirez',_binary 'f�ӣ�\nߵ\�\�\�1?;���㾁��_S\�\�-���','+593-9-98765442',1),(78,'Juan Luna Castro',_binary '����8\�)\�ҡ�	�㬊\�~0vaA�[x�','+593-9-98765443',0),(79,'Valeria Perez Rojas',_binary '\�Y\�*e7�?\��\�\�r��	(8v�F��32x�k','+593-9-98765444',1),(80,'Diego Martinez Cruz',_binary '��\�\�\�[H��\�\�[�\�\��uf\�˷}-!\�}','+593-9-98765445',0),(81,'Martina Torres Flores',_binary 'z_\�C,�iÝ��	(8v�F��32x�k','+593-9-98765446',1),(82,'Joaquin Salazar Gomez',_binary 'AMU̠k f�k\�j\�|�w\��uf\�˷}-!\�}','+593-9-98765447',0),(83,'Clara Diaz Vega',_binary 'F2��\�Y�|\�\�&	�_\�\�\�Xih� \0\�M�','+593-9-98765448',1),(84,'Emiliano Ruiz Castro',_binary 'E�\�4\\jEV$0\Z\�\��P���㾁��_S\�\�-���','+593-9-98765449',0),(85,'Antonia Morales Rivas',_binary '\Zuߧ\�InX�c\�ó{\��uf\�˷}-!\�}','+593-9-98765450',1);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_ventas`
--

DROP TABLE IF EXISTS `detalle_ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_ventas` (
  `id_detalle` int NOT NULL AUTO_INCREMENT,
  `id_venta` int NOT NULL,
  `id_producto` int NOT NULL,
  `cantidad` int NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `id_producto` (`id_producto`),
  KEY `idx_venta_producto` (`id_venta`,`id_producto`),
  CONSTRAINT `detalle_ventas_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id_venta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalle_ventas_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalle_ventas_chk_1` CHECK ((`cantidad` > 0)),
  CONSTRAINT `detalle_ventas_chk_2` CHECK ((`precio_unitario` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_ventas`
--

LOCK TABLES `detalle_ventas` WRITE;
/*!40000 ALTER TABLE `detalle_ventas` DISABLE KEYS */;
INSERT INTO `detalle_ventas` VALUES (1,1,1,2,1.50),(2,2,5,3,0.80),(3,3,3,1,5.50),(4,4,7,2,2.00),(5,5,9,3,1.20),(6,6,11,1,3.50),(7,7,13,2,1.80),(8,8,15,1,2.50),(9,9,17,1,4.00),(10,10,19,1,6.50),(11,11,21,2,1.90),(12,12,22,1,2.20),(13,13,23,1,3.00),(14,14,24,2,3.50),(15,15,25,3,2.80),(16,16,1,1,1.50),(17,17,3,1,5.50),(18,18,5,2,0.80),(19,19,7,1,2.00),(20,20,9,2,1.20),(21,21,11,1,3.50),(22,22,13,2,1.80),(23,23,15,1,2.50),(24,24,17,2,4.00),(25,25,19,1,6.50),(26,26,26,2,2.00),(27,27,27,1,3.50),(28,28,28,1,5.00),(29,29,29,2,4.50),(30,30,30,3,1.00),(31,31,31,2,2.70),(32,32,32,1,2.50),(33,33,33,2,1.50),(34,34,34,3,1.00),(35,35,35,2,1.20),(36,36,36,1,3.80),(37,37,37,1,4.00),(38,38,38,2,1.50),(39,39,39,2,1.90),(40,40,40,1,2.80),(41,41,41,1,2.00),(42,42,42,1,4.20),(43,43,43,1,2.50),(44,44,44,1,5.50),(45,45,45,1,5.20),(46,46,46,2,2.00),(47,47,47,1,1.80),(48,48,48,1,2.90),(49,49,49,1,3.80),(50,50,50,2,2.50),(55,52,1,2,1.50),(56,53,1,2,1.50),(61,55,1,2,1.50),(63,56,56,2,2.50);
/*!40000 ALTER TABLE `detalle_ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_control_stock_venta` AFTER INSERT ON `detalle_ventas` FOR EACH ROW BEGIN
  DECLARE v_id_inventario INT;

  -- Seleccionar el inventario más reciente para el producto vendido
  SELECT id_inventario
  INTO v_id_inventario
  FROM inventario
  WHERE id_producto = NEW.id_producto
  ORDER BY fecha_entrada DESC
  LIMIT 1;

  -- Actualizar la cantidad en inventario
  UPDATE inventario
  SET cantidad = cantidad - NEW.cantidad
  WHERE id_inventario = v_id_inventario;

  -- Registrar la acción en log_acciones
  INSERT INTO log_acciones (id_usuario, accion, tabla, id_afectado, fecha)
  VALUES (
    2, -- ID de usuario que ejecuta la venta (ej. cajero, ajustable según lógica)
    'venta_stock',
    'inventario',
    v_id_inventario,
    NOW()
  );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `devoluciones`
--

DROP TABLE IF EXISTS `devoluciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devoluciones` (
  `id_devolucion` int NOT NULL AUTO_INCREMENT,
  `id_venta` int NOT NULL,
  `id_producto` int NOT NULL,
  `cantidad` int NOT NULL,
  `motivo` text NOT NULL,
  `fecha` date NOT NULL,
  `id_usuario` int NOT NULL,
  PRIMARY KEY (`id_devolucion`),
  KEY `id_venta` (`id_venta`),
  KEY `id_producto` (`id_producto`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `devoluciones_ibfk_1` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id_venta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `devoluciones_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `devoluciones_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `devoluciones_chk_1` CHECK ((`cantidad` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devoluciones`
--

LOCK TABLES `devoluciones` WRITE;
/*!40000 ALTER TABLE `devoluciones` DISABLE KEYS */;
INSERT INTO `devoluciones` VALUES (1,1,1,1,'Envase danado durante transporte','2025-08-02',11),(2,2,5,2,'Fecha de vencimiento proxima','2025-08-02',11),(3,3,3,1,'Error en la seleccion del producto','2025-08-02',11),(4,4,7,1,'Producto no deseado por el cliente','2025-08-02',11),(5,5,9,2,'Producto defectuoso al abrir','2025-08-02',11),(6,6,11,1,'Cambio de opinion del cliente','2025-08-02',11),(7,7,13,1,'Envase roto al recibir','2025-08-02',11),(8,8,15,1,'Error en el pedido enviado','2025-08-02',11),(9,9,17,1,'No conforme con la calidad','2025-08-02',11),(10,10,19,1,'Producto danado en tienda','2025-08-02',11),(11,11,21,2,'Fecha de vencimiento proxima','2025-08-02',11),(12,12,22,1,'Cambio de opinion del cliente','2025-08-02',11),(13,13,23,1,'Producto defectuoso','2025-08-02',11),(14,14,24,2,'Error en la seleccion','2025-08-02',11),(15,15,25,1,'No deseado por el cliente','2025-08-02',11),(16,16,1,1,'Envase danado','2025-08-02',11),(17,17,3,1,'Producto defectuoso','2025-08-02',11),(18,18,5,2,'Fecha de vencimiento proxima','2025-08-02',11),(19,19,7,1,'Error en el pedido','2025-08-02',11),(20,20,9,2,'No conforme con calidad','2025-08-02',11),(21,21,11,1,'Cambio de opinion','2025-08-02',11),(22,22,13,2,'Envase roto','2025-08-02',11),(23,23,15,1,'Error en la seleccion','2025-08-02',11),(24,24,17,2,'Producto defectuoso','2025-08-02',11),(25,25,19,1,'No deseado por el cliente','2025-08-02',11),(26,26,26,1,'Envase danado','2025-08-03',11),(27,27,27,1,'Producto defectuoso','2025-08-03',11),(28,28,28,1,'Error en la seleccion','2025-08-03',11),(29,29,29,1,'No deseado por el cliente','2025-08-03',11),(30,30,30,2,'Fecha de vencimiento proxima','2025-08-03',11);
/*!40000 ALTER TABLE `devoluciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario`
--

DROP TABLE IF EXISTS `inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario` (
  `id_inventario` int NOT NULL AUTO_INCREMENT,
  `id_producto` int NOT NULL,
  `cantidad` int NOT NULL,
  `fecha_entrada` date NOT NULL,
  `id_usuario` int NOT NULL,
  PRIMARY KEY (`id_inventario`),
  KEY `id_producto` (`id_producto`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inventario_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inventario_chk_1` CHECK ((`cantidad` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
INSERT INTO `inventario` VALUES (1,1,5,'2025-07-01',3),(2,2,80,'2025-07-02',3),(3,3,50,'2025-07-03',3),(4,4,60,'2025-07-04',3),(5,5,200,'2025-07-05',3),(6,6,120,'2025-07-06',3),(7,7,90,'2025-07-07',3),(8,8,150,'2025-07-08',3),(9,9,140,'2025-07-09',3),(10,10,110,'2025-07-10',3),(11,11,130,'2025-07-11',3),(12,12,100,'2025-07-12',3),(13,13,80,'2025-07-13',3),(14,14,90,'2025-07-14',3),(15,15,70,'2025-07-15',3),(16,16,60,'2025-07-16',3),(17,17,50,'2025-07-17',3),(18,18,40,'2025-07-18',3),(19,19,30,'2025-07-19',3),(20,20,25,'2025-07-20',3),(21,21,200,'2025-07-21',3),(22,22,180,'2025-07-22',3),(23,23,100,'2025-07-23',3),(24,24,70,'2025-07-24',3),(25,25,90,'2025-07-25',3),(26,26,120,'2025-07-26',3),(27,27,100,'2025-07-27',3),(28,28,60,'2025-07-28',3),(29,29,70,'2025-07-29',3),(30,30,180,'2025-07-30',3),(31,31,130,'2025-07-31',3),(32,32,100,'2025-08-01',3),(33,33,140,'2025-08-02',3),(34,34,150,'2025-08-03',3),(35,35,110,'2025-08-04',3),(36,36,120,'2025-08-05',3),(37,37,100,'2025-08-06',3),(38,38,80,'2025-08-07',3),(39,39,90,'2025-08-08',3),(40,40,70,'2025-08-09',3),(41,41,60,'2025-08-10',3),(42,42,50,'2025-08-11',3),(43,43,40,'2025-08-12',3),(44,44,30,'2025-08-13',3),(45,45,25,'2025-08-14',3),(46,46,200,'2025-08-15',3),(47,47,180,'2025-08-16',3),(48,48,100,'2025-08-17',3),(49,49,70,'2025-08-18',3),(50,50,90,'2025-08-19',3);
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_notificacion_stock_bajo` AFTER UPDATE ON `inventario` FOR EACH ROW begin
  if new.cantidad < 10 then
    insert into log_acciones (id_usuario, accion, tabla, id_afectado, fecha)
    values (
      3, -- id del usuario encargado de inventario
      'stock_bajo',
      'inventario',
      new.id_inventario,
      now()
    );
  end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `log_acciones`
--

DROP TABLE IF EXISTS `log_acciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_acciones` (
  `id_log` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `accion` varchar(50) NOT NULL,
  `tabla` varchar(50) NOT NULL,
  `id_afectado` int DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_log`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `log_acciones_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_acciones`
--

LOCK TABLES `log_acciones` WRITE;
/*!40000 ALTER TABLE `log_acciones` DISABLE KEYS */;
INSERT INTO `log_acciones` VALUES (1,1,'INSERT','Productos',1,'2025-08-01 08:00:00',NULL),(2,2,'INSERT','Ventas',1,'2025-08-01 09:00:00',NULL),(3,3,'UPDATE','Inventario',1,'2025-08-01 10:00:00',NULL),(4,4,'SELECT','Ventas',NULL,'2025-08-01 11:00:00',NULL),(5,5,'INSERT','Promociones',1,'2025-08-01 12:00:00',NULL),(6,6,'INSERT','Clientes',1,'2025-08-01 13:00:00',NULL),(7,7,'SELECT','Log_Acciones',NULL,'2025-08-01 14:00:00',NULL),(8,8,'INSERT','Producto_Promocion',1,'2025-08-01 15:00:00',NULL),(9,9,'UPDATE','Inventario',2,'2025-08-01 16:00:00',NULL),(10,10,'INSERT','Detalle_Ventas',1,'2025-08-01 17:00:00',NULL),(11,11,'INSERT','Devoluciones',1,'2025-08-01 18:00:00',NULL),(12,12,'SELECT','Ventas',NULL,'2025-08-01 19:00:00',NULL),(13,13,'INSERT','Producto_Proveedor',1,'2025-08-01 20:00:00',NULL),(14,14,'UPDATE','Usuarios',1,'2025-08-01 21:00:00',NULL),(15,15,'UPDATE','Inventario',3,'2025-08-01 22:00:00',NULL),(16,16,'INSERT','Productos',2,'2025-08-02 08:00:00',NULL),(17,17,'INSERT','Promociones',2,'2025-08-02 09:00:00',NULL),(18,18,'INSERT','Clientes',2,'2025-08-02 10:00:00',NULL),(19,19,'SELECT','Ventas',NULL,'2025-08-02 11:00:00',NULL),(20,20,'INSERT','Detalle_Ventas',2,'2025-08-02 12:00:00',NULL),(21,21,'SELECT','Log_Acciones',NULL,'2025-08-02 13:00:00',NULL),(22,22,'INSERT','Devoluciones',2,'2025-08-02 14:00:00',NULL),(23,23,'UPDATE','Productos',3,'2025-08-02 15:00:00',NULL),(24,24,'INSERT','Promociones',3,'2025-08-02 16:00:00',NULL),(25,25,'SELECT','Clientes',NULL,'2025-08-02 17:00:00',NULL),(26,2,'venta_stock','inventario',1,'2025-08-03 16:57:57',NULL),(27,3,'stock_bajo','inventario',1,'2025-08-03 17:01:29',NULL),(28,2,'venta_stock','inventario',NULL,'2025-08-03 17:54:23',NULL);
/*!40000 ALTER TABLE `log_acciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto_promocion`
--

DROP TABLE IF EXISTS `producto_promocion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto_promocion` (
  `id_producto` int NOT NULL,
  `id_promocion` int NOT NULL,
  PRIMARY KEY (`id_producto`,`id_promocion`),
  KEY `id_promocion` (`id_promocion`),
  CONSTRAINT `producto_promocion_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `producto_promocion_ibfk_2` FOREIGN KEY (`id_promocion`) REFERENCES `promociones` (`id_promocion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto_promocion`
--

LOCK TABLES `producto_promocion` WRITE;
/*!40000 ALTER TABLE `producto_promocion` DISABLE KEYS */;
INSERT INTO `producto_promocion` VALUES (1,1),(2,1),(3,2),(4,2),(5,3),(6,3),(7,4),(8,4),(9,5),(10,5),(11,6),(12,6),(13,7),(14,7),(15,8),(16,8),(17,9),(18,9),(19,10),(20,10),(21,11),(22,15),(23,16),(24,17),(25,18),(26,26),(27,27),(28,28),(29,28),(30,29),(31,29),(32,30),(33,30),(34,31),(35,31);
/*!40000 ALTER TABLE `producto_promocion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto_proveedor`
--

DROP TABLE IF EXISTS `producto_proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto_proveedor` (
  `id_producto` int NOT NULL,
  `id_proveedor` int NOT NULL,
  PRIMARY KEY (`id_producto`,`id_proveedor`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `producto_proveedor_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `producto_proveedor_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto_proveedor`
--

LOCK TABLES `producto_proveedor` WRITE;
/*!40000 ALTER TABLE `producto_proveedor` DISABLE KEYS */;
INSERT INTO `producto_proveedor` VALUES (1,1),(2,1),(33,1),(3,2),(4,2),(34,2),(5,3),(6,3),(35,3),(7,4),(8,4),(36,4),(9,5),(10,5),(37,5),(11,6),(12,6),(38,6),(13,7),(14,7),(39,7),(15,8),(16,8),(40,8),(17,9),(18,9),(41,9),(19,10),(20,10),(42,10),(21,11),(43,11),(44,12),(45,13),(46,14),(22,15),(47,15),(23,16),(48,16),(24,17),(49,17),(25,18),(50,18),(26,19),(27,20),(28,21),(29,22),(30,23),(31,24),(32,25);
/*!40000 ALTER TABLE `producto_proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id_producto` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `id_categoria` int NOT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `id_categoria` (`id_categoria`),
  KEY `idx_nombre_producto` (`nombre`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `productos_chk_1` CHECK ((`precio` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'Leche Entera 1L',1.80,1,'2025-12-01'),(2,'Leche Descremada 1L',1.60,1,'2025-12-15'),(3,'Carne de Res 1kg',5.50,2,NULL),(4,'Pollo Entero 1.5kg',4.00,2,NULL),(5,'Agua Mineral 1.5L',0.80,3,'2026-06-01'),(6,'Jugo de Naranja 1L',2.50,3,'2025-11-01'),(7,'Pan Integral 500g',2.00,4,'2025-08-10'),(8,'Croissant 100g',1.20,4,'2025-08-05'),(9,'Manzana Roja 1kg',1.20,5,'2025-09-01'),(10,'Brocoli 500g',1.50,5,'2025-08-20'),(11,'Cereal Maiz 500g',3.50,6,'2026-03-01'),(12,'Avena Integral 1kg',2.80,6,'2026-05-01'),(13,'Atun Enlatado 170g',1.80,7,'2027-01-01'),(14,'Frijoles Enlatados 400g',1.40,7,'2027-02-01'),(15,'Detergente Liquido 1L',2.50,8,NULL),(16,'Jabon Liquido 500ml',1.90,8,NULL),(17,'Shampoo Anticaspa 400ml',4.00,9,'2026-12-01'),(18,'Pasta Dental 100ml',2.20,9,'2026-10-01'),(19,'Pizza Congelada 400g',6.50,10,'2026-02-01'),(20,'Helado Vainilla 1L',5.00,10,'2026-03-01'),(21,'Papas Fritas 200g',1.90,11,'2025-11-01'),(22,'Chocolates 100g',2.20,15,'2026-04-01'),(23,'Leche de Almendra 1L',3.00,16,'2026-01-01'),(24,'Pan sin Gluten 400g',3.50,17,'2025-08-20'),(25,'Bebida Energetica 500ml',2.80,18,'2026-05-01'),(26,'Yogurt Natural 500ml',2.00,1,'2025-12-20'),(27,'Queso Fresco 500g',3.50,1,'2025-11-15'),(28,'Carne Molida 1kg',5.00,2,NULL),(29,'Pechuga de Pollo 1kg',4.50,2,NULL),(30,'Agua con Gas 1.5L',1.00,3,'2026-07-01'),(31,'Jugo de Manzana 1L',2.70,3,'2025-11-15'),(32,'Pan de Molde 600g',2.50,4,'2025-08-12'),(33,'Baguette 300g',1.50,4,'2025-08-07'),(34,'Banano 1kg',1.00,5,'2025-09-10'),(35,'Zanahoria 500g',1.20,5,'2025-08-25'),(36,'Cereal de Trigo 500g',3.80,6,'2026-04-01'),(37,'Quinoa 1kg',4.00,6,'2026-06-01'),(38,'Maiz Enlatado 400g',1.50,7,'2027-03-01'),(39,'Sardinas Enlatadas 170g',1.90,7,'2027-04-01'),(40,'Suavizante Ropa 1L',2.80,8,NULL),(41,'Desinfectante 500ml',2.00,8,NULL),(42,'Acondicionador 400ml',4.20,9,'2026-11-01'),(43,'Crema Dental 150ml',2.50,9,'2026-09-01'),(44,'Nuggets Congelados 500g',5.50,10,'2026-01-15'),(45,'Helado Chocolate 1L',5.20,10,'2026-02-15'),(46,'Nachos 200g',2.00,11,'2025-12-01'),(47,'Caramelos 100g',1.80,15,'2026-03-01'),(48,'Leche de Soya 1L',2.90,16,'2026-02-01'),(49,'Pan sin Gluten 500g',3.80,17,'2025-08-25'),(50,'Bebida Isotonica 500ml',2.50,18,'2026-06-01');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promociones`
--

DROP TABLE IF EXISTS `promociones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promociones` (
  `id_promocion` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descuento` decimal(5,2) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  PRIMARY KEY (`id_promocion`),
  CONSTRAINT `promociones_chk_1` CHECK ((`descuento` between 0 and 100)),
  CONSTRAINT `promociones_chk_2` CHECK ((`fecha_fin` >= `fecha_inicio`))
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promociones`
--

LOCK TABLES `promociones` WRITE;
/*!40000 ALTER TABLE `promociones` DISABLE KEYS */;
INSERT INTO `promociones` VALUES (1,'Descuento Lacteos 10%',10.00,'2025-08-01','2025-08-15'),(2,'Oferta Carnes 15%',15.00,'2025-08-02','2025-08-16'),(3,'Promo Bebidas 20%',20.00,'2025-08-03','2025-08-17'),(4,'Panaderia 2x1',50.00,'2025-08-04','2025-08-18'),(5,'Frutas Frescas 10%',10.00,'2025-08-05','2025-08-19'),(6,'Cereales Saludables 15%',15.00,'2025-08-06','2025-08-20'),(7,'Enlatados Oferta 20%',20.00,'2025-08-07','2025-08-21'),(8,'Limpieza Total 25%',25.00,'2025-08-08','2025-08-22'),(9,'Cuidado Personal 10%',10.00,'2025-08-09','2025-08-23'),(10,'Congelados Baratos 15%',15.00,'2025-08-10','2025-08-24'),(11,'Snacks Promo 20%',20.00,'2025-08-11','2025-08-25'),(12,'Vino Especial 30%',30.00,'2025-08-12','2025-08-26'),(13,'Pescados Frescos 15%',15.00,'2025-08-13','2025-08-27'),(14,'Condimentos Oferta 10%',10.00,'2025-08-14','2025-08-28'),(15,'Dulces Baratos 20%',20.00,'2025-08-15','2025-08-29'),(16,'Veganos Descuento 15%',15.00,'2025-08-16','2025-08-30'),(17,'Pan sin Gluten 25%',25.00,'2025-08-17','2025-08-31'),(18,'Energia Total 20%',20.00,'2025-08-18','2025-09-01'),(19,'Mascotas Promo 10%',10.00,'2025-08-19','2025-09-02'),(20,'Hogar Oferta 15%',15.00,'2025-08-20','2025-09-03'),(21,'Frutos Secos 20%',20.00,'2025-08-21','2025-09-04'),(22,'Pastas Baratas 10%',10.00,'2025-08-22','2025-09-05'),(23,'Aceites Oferta 15%',15.00,'2025-08-23','2025-09-06'),(24,'Salsas Promo 20%',20.00,'2025-08-24','2025-09-07'),(25,'Postres Dulces 25%',25.00,'2025-08-25','2025-09-08'),(26,'Descuento Yogurt 15%',15.00,'2025-08-26','2025-09-09'),(27,'Oferta Queso 10%',10.00,'2025-08-27','2025-09-10'),(28,'Promo Carnes 20%',20.00,'2025-08-28','2025-09-11'),(29,'Bebidas Gas 25%',25.00,'2025-08-29','2025-09-12'),(30,'Pan Oferta 15%',15.00,'2025-08-30','2025-09-13'),(31,'Frutas 20%',20.00,'2025-08-31','2025-09-14'),(32,'Cereales Promo 10%',10.00,'2025-09-01','2025-09-15'),(33,'Enlatados 15%',15.00,'2025-09-02','2025-09-16'),(34,'Limpieza 20%',20.00,'2025-09-03','2025-09-17'),(35,'Cuidado Personal 25%',25.00,'2025-09-04','2025-09-18');
/*!40000 ALTER TABLE `promociones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id_proveedor` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_proveedor`),
  CONSTRAINT `proveedores_chk_1` CHECK ((`nombre` <> _utf8mb4''))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Lacteos del Valle','Juan Perez','+593-9-98765401'),(2,'Carnes Premium','Maria Gomez','+593-9-98765402'),(3,'Bebidas Frescas','Carlos Lopez','+593-9-98765403'),(4,'Panaderia La Estrella','Ana Ruiz','+593-9-98765404'),(5,'Frutas del Campo','Luis Martinez','+593-9-98765405'),(6,'Cereales Salud','Sofia Diaz','+593-9-98765406'),(7,'Enlatados Global','Pedro Sanchez','+593-9-98765407'),(8,'Limpieza Total','Laura Fernandez','+593-9-98765408'),(9,'Cuidado Plus','Diego Torres','+593-9-98765409'),(10,'Congelados Frio','Clara Morales','+593-9-98765410'),(11,'Snacks Sabrosos','Javier Romero','+593-9-98765411'),(12,'Bebidas Premium','Elena Castro','+593-9-98765412'),(13,'Pescados del Mar','Miguel Vargas','+593-9-98765413'),(14,'Condimentos Rico','Paula Herrera','+593-9-98765414'),(15,'Dulces Delicia','Andres Mendoza','+593-9-98765415'),(16,'Veganos Natural','Lucia Ortiz','+593-9-98765416'),(17,'Pan Especial','Roberto Silva','+593-9-98765417'),(18,'Energia Total','Carmen Ramirez','+593-9-98765418'),(19,'Mascotas Felices','Gabriel Luna','+593-9-98765419'),(20,'Hogar Practico','Valeria Rojas','+593-9-98765420'),(21,'Frutos Secos SA','Daniel Cruz','+593-9-98765421'),(22,'Pastas Italia','Marina Flores','+593-9-98765422'),(23,'Aceites Puro','Hector Gomez','+593-9-98765423'),(24,'Salsas Sabores','Natalia Vega','+593-9-98765424'),(25,'Postres Dulces','Felipe Castro','+593-9-98765425');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id_rol` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `privilegios` text,
  PRIMARY KEY (`id_rol`),
  CONSTRAINT `roles_chk_1` CHECK ((`nombre` <> _utf8mb4''))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','Acceso total al sistema'),(2,'Cajero','Registro de ventas y devoluciones'),(3,'Bodeguero','Gestion de inventario y stock'),(4,'Supervisor','Revision de reportes y auditorias'),(5,'Gerente','Gestion de promociones y usuarios'),(6,'Recepcionista','Registro y gestion de clientes'),(7,'Auditor','Acceso a logs de acciones'),(8,'Encargado Promociones','Creacion y edicion de promociones'),(9,'Encargado Inventario','Control de entradas y salidas de stock'),(10,'Asistente Caja','Apoyo en registro de ventas'),(11,'Encargado Devoluciones','Procesamiento de devoluciones'),(12,'Analista Datos','Generacion de reportes y estadisticas'),(13,'Encargado Proveedores','Gestion de proveedores'),(14,'Encargado Seguridad','Control de accesos y permisos'),(15,'Asistente Bodega','Apoyo en gestion de inventario'),(16,'Encargado Limpieza','Registro de productos de limpieza'),(17,'Asistente Promociones','Apoyo en gestion de promociones'),(18,'Encargado Clientes','Gestion de clientes frecuentes'),(19,'Asistente Gerente','Apoyo en tareas administrativas'),(20,'Encargado Ventas','Supervision de ventas diarias'),(21,'Asistente Auditoria','Apoyo en revision de logs'),(22,'Encargado Productos','Gestion de catalogo de productos'),(23,'Asistente Seguridad','Apoyo en control de accesos'),(24,'Encargado Postres','Gestion de postres y reposteria'),(25,'Asistente General','Tareas generales de apoyo');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `id_rol` int NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `usuarios_chk_1` CHECK ((`nombre` <> _utf8mb4''))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Admin Sistema',1,'0e89f223e226ae63268cf39152ab75722e811b89d29efb22a852f1667bd22ae0'),(2,'Cajero Juan',2,'f24e40fba29853cb35c014654ada2cca413ff7361d67c19b7056060f841ce58b'),(3,'Bodeguero Ana',3,'27d099fd0da0afbc86a132ab1f687838dda869a50cf3cd8da918c2becf155bbb'),(4,'Supervisor Carlos',4,'d172ab135ba5a1cbeb97e74a201c2053096ddf950b8b4e20cf8c96663850f789'),(5,'Gerente Maria',5,'5fbd74f8502c3e49daed9f4b975ea3102f1545c496fb19a1f8a3e898fc817648'),(6,'Recepcionista Luis',6,'5fcd9fe1c3dc6d3e75f83d5549a2371522aba4c9cd34809ee83589081ccc5215'),(7,'Auditor Sofia',7,'55b2f75a2420b0f5b0366d9c8fa5cd930fb6ad95e51c2bdd7f7d55d4d3b9d39c'),(8,'Promo Laura',8,'7092f60d6b482c9b88b1a76bf4372c2935d887ae5ab95479cbb12f43034c80e3'),(9,'Inventario Diego',9,'a08066379dd21195a18d64407c5d6d2f8a78da4beb41c8d74b0493867af0dea6'),(10,'Asistente Caja Clara',10,'51872de9b0bdb5f1a61f1c1afb90647087907a1f34ca16c181ed6130cc899005'),(11,'Devoluciones Javier',11,'c17b089ec9b921e3112244c075633bd5c86b76578ed61788da874993654b4f6c'),(12,'Analista Pedro',12,'9ca37b285cbb5d6517d372014492612fe0e593951cc6accc8f99b4e97a6bfaf6'),(13,'Proveedores Elena',13,'c5c6b1f95bd0a945684b85e8f9f9d0482e2707e28aabacbe37d59d1c717d12f3'),(14,'Seguridad Miguel',14,'be3ae9b6fbdf100c4e1a56040b3dfa25a81cf1911c2671240044a5d357d13fd3'),(15,'Asistente Bodega Paula',15,'91a8757322674aefa3bce13c6420edd46f0f1add7b3e9da0bb61437e73c418e1'),(16,'Limpieza Andres',16,'37d1bddf28c8787b6cc7e6d0f5ccb15f10892fae085289cb815c4e154996ca11'),(17,'Asistente Promo Lucia',17,'e2c851bc1c8717a66fcafdc4b761c15c46693937edd7635c595cd56c0227666d'),(18,'Clientes Roberto',18,'a075d33a7307eadfd016833b08bd0902d72338b079e37390808170b9a6817ead'),(19,'Asistente Gerente Carmen',19,'71e65c366984cc019061ee62d1eb5592ebe5cbf33dbd7e5fdc9cf6581474d36c'),(20,'Ventas Gabriel',20,'29aa4e58e9c48819e4d076688302a35140aad0f0104e2be10e5e5ccad822d26a'),(21,'Asistente Auditoria Valeria',21,'600d37a614fe73e7d76f394bce7365c95536a56feffba14ed00edbd8ca64ccbf'),(22,'Productos Daniel',22,'9b7052944f9f496d9af66ffa78ffd1877938f86cb07f278412343edf901a8f6b'),(23,'Asistente Seguridad Marina',23,'64b3e81bf2bb6f2d882a73875b7612b0e1d072e3b2925c1b149d509fa44b8715'),(24,'Postres Hector',24,'2a99fb1422840bd76184f3882c02418dd65e08f025b4429f00e5b222e3f35397'),(25,'Asistente General Natalia',25,'7b5ed34e5ee9bcc01bf4fa6ffc8352d5239b780eac1ddf46ae5599cf1783b201');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventas` (
  `id_venta` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `fecha` datetime NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `id_usuario` int NOT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_usuario` (`id_usuario`),
  KEY `idx_fecha_ventas` (`fecha`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_chk_1` CHECK ((`total` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
INSERT INTO `ventas` VALUES (1,1,'2025-08-01 09:00:00',15.50,2),(2,2,'2025-08-01 09:30:00',8.00,2),(3,3,'2025-08-01 10:00:00',20.00,2),(4,4,'2025-08-01 10:30:00',12.50,2),(5,5,'2025-08-01 11:00:00',30.00,2),(6,6,'2025-08-01 11:30:00',7.80,2),(7,7,'2025-08-01 12:00:00',18.90,2),(8,8,'2025-08-01 12:30:00',25.00,2),(9,9,'2025-08-01 13:00:00',14.40,2),(10,10,'2025-08-01 13:30:00',22.50,2),(11,11,'2025-08-01 14:00:00',16.70,2),(12,12,'2025-08-01 14:30:00',9.00,2),(13,13,'2025-08-01 15:00:00',28.00,2),(14,14,'2025-08-01 15:30:00',11.20,2),(15,15,'2025-08-01 16:00:00',19.50,2),(16,16,'2025-08-01 16:30:00',13.80,2),(17,17,'2025-08-01 17:00:00',21.00,2),(18,18,'2025-08-01 17:30:00',10.50,2),(19,19,'2025-08-01 18:00:00',17.90,2),(20,20,'2025-08-01 18:30:00',24.00,2),(21,21,'2025-08-01 19:00:00',15.30,2),(22,22,'2025-08-01 19:30:00',8.50,2),(23,23,'2025-08-01 20:00:00',26.00,2),(24,24,'2025-08-01 20:30:00',12.00,2),(25,25,'2025-08-01 21:00:00',18.00,2),(26,26,'2025-08-02 09:00:00',10.00,2),(27,27,'2025-08-02 09:30:00',12.50,2),(28,28,'2025-08-02 10:00:00',15.00,2),(29,29,'2025-08-02 10:30:00',8.50,2),(30,30,'2025-08-02 11:00:00',20.00,2),(31,31,'2025-08-02 11:30:00',14.20,2),(32,32,'2025-08-02 12:00:00',17.90,2),(33,33,'2025-08-02 12:30:00',22.00,2),(34,34,'2025-08-02 13:00:00',11.50,2),(35,35,'2025-08-02 13:30:00',16.80,2),(36,36,'2025-08-02 14:00:00',13.00,2),(37,37,'2025-08-02 14:30:00',19.50,2),(38,38,'2025-08-02 15:00:00',25.00,2),(39,39,'2025-08-02 15:30:00',9.00,2),(40,40,'2025-08-02 16:00:00',12.70,2),(41,41,'2025-08-02 16:30:00',18.40,2),(42,42,'2025-08-02 17:00:00',14.60,2),(43,43,'2025-08-02 17:30:00',21.20,2),(44,44,'2025-08-02 18:00:00',16.90,2),(45,45,'2025-08-02 18:30:00',10.30,2),(46,46,'2025-08-02 19:00:00',23.50,2),(47,47,'2025-08-02 19:30:00',13.80,2),(48,48,'2025-08-02 20:00:00',17.00,2),(49,49,'2025-08-02 20:30:00',11.40,2),(50,50,'2025-08-02 21:00:00',15.60,2),(51,1,'2025-08-03 16:35:53',3.00,2),(52,1,'2025-08-03 16:48:47',20.00,2),(53,1,'2025-08-03 16:52:37',30.00,2),(54,1,'2025-08-03 16:54:56',30.00,2),(55,1,'2025-08-03 16:57:43',5.00,2);
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-03 19:18:52

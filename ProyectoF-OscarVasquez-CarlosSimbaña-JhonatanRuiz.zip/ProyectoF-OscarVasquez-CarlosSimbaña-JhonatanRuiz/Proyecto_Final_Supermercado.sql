-- Esquema y datos existentes de la base de datos (omitidos por brevedad)
use  supermercadoProyecto;
-- Procedimiento 1: Inserción Validada para Productos
DELIMITER //
CREATE PROCEDURE Insertar_Producto_Validado(
    IN p_nombre VARCHAR(100),
    IN p_precio DECIMAL(10,2),
    IN p_id_categoria INT,
    IN p_fecha_vencimiento DATE,
    IN p_id_proveedor INT,
    IN p_id_usuario INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error al insertar el producto';
    END;

    START TRANSACTION;
    IF p_nombre = '' OR p_precio < 0 OR p_id_categoria <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Datos de entrada inválidos';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Categorias WHERE id_categoria = p_id_categoria) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Categoría no encontrada';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Proveedores WHERE id_proveedor = p_id_proveedor) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Proveedor no encontrado';
    END IF;
    INSERT INTO Productos (nombre, precio, id_categoria, fecha_vencimiento)
    VALUES (p_nombre, p_precio, p_id_categoria, p_fecha_vencimiento);
    INSERT INTO Producto_Proveedor (id_producto, id_proveedor)
    VALUES (LAST_INSERT_ID(), p_id_proveedor);
    INSERT INTO Log_Acciones (id_usuario, accion, tabla, id_afectado, fecha)
    VALUES (p_id_usuario, 'INSERT', 'Productos', LAST_INSERT_ID(), NOW());
    COMMIT;
END //
DELIMITER ;

-- Procedimiento 2: Actualización Masiva de Precios por Categoría
DELIMITER //
CREATE PROCEDURE ActualizarPreciosPorCategoria(
    IN p_id_categoria INT,
    IN p_porcentaje_aumento DECIMAL(5,2),
    IN p_id_usuario INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error al actualizar precios';
    END;

    START TRANSACTION;
    IF p_porcentaje_aumento < 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Porcentaje de aumento inválido';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM Categorias WHERE id_categoria = p_id_categoria) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Categoría no encontrada';
    END IF;
    UPDATE Productos 
    SET precio = precio * (1 + p_porcentaje_aumento/100)
    WHERE id_categoria = p_id_categoria;
    INSERT INTO Log_Acciones (id_usuario, accion, tabla, id_afectado, fecha)
    VALUES (p_id_usuario, 'UPDATE', 'Productos', NULL, NOW());
    COMMIT;
END //
DELIMITER ;

-- Procedimiento 3: Eliminación Segura de Producto
DELIMITER //
CREATE PROCEDURE EliminarProductoSeguro(
    IN p_id_producto INT,
    IN p_id_usuario INT
)
BEGIN
    DECLARE v_cant_ventas INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error al eliminar producto';
    END;

    START TRANSACTION;
    IF NOT EXISTS (SELECT 1 FROM Productos WHERE id_producto = p_id_producto) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Producto no encontrado';
    END IF;
    SELECT COUNT(*) INTO v_cant_ventas 
    FROM Detalle_Ventas 
    WHERE id_producto = p_id_producto;
    IF v_cant_ventas > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No se puede eliminar producto con ventas asociadas';
    END IF;
    DELETE FROM Producto_Proveedor WHERE id_producto = p_id_producto;
    DELETE FROM Producto_Promocion WHERE id_producto = p_id_producto;
    DELETE FROM Inventario WHERE id_producto = p_id_producto;
    DELETE FROM Productos WHERE id_producto = p_id_producto;
    INSERT INTO Log_Acciones (id_usuario, accion, tabla, id_afectado, fecha)
    VALUES (p_id_usuario, 'DELETE', 'Productos', p_id_producto, NOW());
    COMMIT;
END //
DELIMITER ;

-- Procedimiento 4: Reporte de Ventas por Categoría
DELIMITER //
CREATE PROCEDURE ReporteVentasPorCategoria(
    IN p_fecha_inicio DATE,
    IN p_fecha_fin DATE
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error al generar reporte';
    END;

    START TRANSACTION;
    IF p_fecha_inicio > p_fecha_fin THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Fecha de inicio debe ser menor o igual a fecha de fin';
    END IF;
    SELECT 
        c.nombre AS categoria,
        COUNT(DISTINCT v.id_venta) AS total_ventas,
        SUM(dv.cantidad) AS total_productos_vendidos,
        SUM(dv.cantidad * dv.precio_unitario) AS total_ingresos
    FROM Categorias c
    LEFT JOIN Productos p ON c.id_categoria = p.id_categoria
    LEFT JOIN Detalle_Ventas dv ON p.id_producto = dv.id_producto
    LEFT JOIN Ventas v ON dv.id_venta = v.id_venta
    WHERE v.fecha BETWEEN p_fecha_inicio AND p_fecha_fin
    GROUP BY c.id_categoria, c.nombre
    ORDER BY total_ingresos DESC;
    INSERT INTO Log_Acciones (id_usuario, accion, tabla, id_afectado, fecha)
    VALUES (1, 'SELECT', 'Ventas', NULL, NOW());
    COMMIT;
END //
DELIMITER ;


-- procedimiento 5: generación de factura 
delimiter //
create procedure generarfacturasimplificada(
    in p_id_cliente int,
    in p_id_usuario int,
    in p_id_producto int,
    in p_cantidad int
)
begin
    declare v_id_venta int;
    declare v_precio decimal(10,2);
    declare v_stock int;
    
    declare exit handler for sqlexception 
    begin
        rollback;
        signal sqlstate '45000' set message_text = 'error al generar factura';
    end;

    start transaction;
    
    -- validar cliente, usuario y producto
    if not exists (select 1 from clientes where id_cliente = p_id_cliente) or
       not exists (select 1 from usuarios where id_usuario = p_id_usuario) or
       not exists (select 1 from productos where id_producto = p_id_producto) then
        signal sqlstate '45000' set message_text = 'cliente, usuario o producto no encontrado';
    end if;
    
    -- validar cantidad
    if p_cantidad <= 0 then
        signal sqlstate '45000' set message_text = 'cantidad inválida';
    end if;
    
    -- validar stock
    select cantidad into v_stock 
    from inventario 
    where id_producto = p_id_producto 
    limit 1;
    
    if v_stock < p_cantidad then
        signal sqlstate '45000' set message_text = 'stock insuficiente';
    end if;
    
    -- obtener precio con descuento si aplica
    select case 
        when pp.id_promocion is not null then p.precio * (1 - pr.descuento/100) 
        else p.precio 
    end into v_precio
    from productos p
    left join producto_promocion pp on p.id_producto = pp.id_producto
    left join promociones pr on pp.id_promocion = pr.id_promocion
    where p.id_producto = p_id_producto 
    and (pr.fecha_inicio <= now() and pr.fecha_fin >= now() or pr.id_promocion is null)
    limit 1;
    
    -- crear venta
    insert into ventas (id_cliente, fecha, total, id_usuario)
    values (p_id_cliente, now(), p_cantidad * v_precio, p_id_usuario);
    
    set v_id_venta = last_insert_id();
    
    -- insertar detalle de venta
    insert into detalle_ventas (id_venta, id_producto, cantidad, precio_unitario)
    values (v_id_venta, p_id_producto, p_cantidad, v_precio);
    
    -- actualizar inventario
    update inventario 
    set cantidad = cantidad - p_cantidad 
    where id_producto = p_id_producto;
    
    -- registrar en log
    insert into log_acciones (id_usuario, accion, tabla, id_afectado, fecha)
    values (p_id_usuario, 'insert', 'ventas', v_id_venta, now());
    
    -- devolver detalles de la factura
    select 
        v.id_venta, 
        v.fecha, 
        v.total, 
        c.nombre as cliente, 
        p.nombre as producto, 
        dv.cantidad, 
        dv.precio_unitario
    from ventas v
    join clientes c on v.id_cliente = c.id_cliente
    join detalle_ventas dv on v.id_venta = dv.id_venta
    join productos p on dv.id_producto = p.id_producto
    where v.id_venta = v_id_venta;
    
    commit;
end //
delimiter ;

-- procedimiento 1: insertarproductovalidado
-- qué hace: inserta un producto nuevo, valida nombre, precio, categoría y proveedor existentes, 
-- agrega relación con proveedor y registra la acción en log_acciones, todo en una transacción.
call Insertar_Producto_Validado('vape 500ml', 2.50, 1, '2026-02-01', 1, 1);
select * from productos where nombre = 'vape 500ml';
select * from log_acciones where accion = 'insert' and tabla = 'productos' order by fecha desc limit 1;

-- prueba de error: intenta insertar con datos inválidos (nombre vacío, categoría inexistente)
call Insertar_Producto_Validado('', -1, 999, '2026-02-01', 999, 1);

-- procedimiento 2: actualizarpreciosporcategoria
-- qué hace: aumenta los precios de todos los productos de una categoría por un porcentaje,
-- valida la categoría y el porcentaje, y registra la acción en log_acciones, en una transacción.
call actualizarpreciosporcategoria(1, 15.00, 1);
select * from productos where id_categoria = 1;
select * from log_acciones where accion = 'update' and tabla = 'productos' order by fecha desc limit 1;

-- prueba de error: intenta actualizar una categoría inexistente
call actualizarpreciosporcategoria(999, 10.00, 1);

-- procedimiento 3: eliminarproductoseguro
-- qué hace: elimina un producto si no tiene ventas asociadas, limpia relaciones en otras tablas
-- (producto_proveedor, producto_promocion, inventario) y registra en log_acciones, en una transacción.
call Insertar_Producto_Validado('producto prueba2', 1.00, 1, '2026-03-01', 1, 1);

call EliminarProductoSeguro(54, 1);
select * from log_acciones where accion = 'delete' and tabla = 'productos' order by fecha desc limit 1;

-- prueba de error: intenta eliminar un producto con ventas asociadas
call eliminarproductoseguro(1, 1);

-- procedimiento 4: reporteventasporcategoria
-- qué hace: genera un reporte de ventas por categoría en un rango de fechas, mostrando total de ventas,
-- productos vendidos e ingresos, valida fechas y registra en log_acciones, en una transacción.
call reporteventasporcategoria('2025-08-01', '2025-08-31');
select * from log_acciones where accion = 'select' and tabla = 'ventas' order by fecha desc limit 1;

-- prueba de error: intenta generar reporte con fechas inválidas (inicio > fin)
call reporteventasporcategoria('2025-08-31', '2025-08-01');

-- procedimiento 5: generarfacturasimplificada
-- qué hace: crea una factura para un solo producto, valida cliente, usuario, producto y stock,
-- aplica descuentos de promociones, actualiza inventario y registra en log_acciones, en una transacción.
call generarfacturasimplificada(1, 2, 1, 2);
select * from ventas order by id_venta desc limit 1;
select * from log_acciones where accion = 'insert' and tabla = 'ventas' order by fecha desc limit 1;

-- prueba de error: intenta crear factura con stock insuficiente
call generarfacturasimplificada(1, 2, 1, 200);

-- /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--- 

-- función 1: totalventascliente
-- calcula el total gastado por un cliente en un rango de fechas, valida cliente y fechas.
DELIMITER //
CREATE FUNCTION totalventascliente(
    cliente_id INT,
    fecha_inicio DATE,
    fecha_fin DATE
) RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE total DECIMAL(10,2);

    -- Validar existencia del cliente
    IF NOT EXISTS (
        SELECT 1 FROM Clientes WHERE id_cliente = cliente_id
    ) THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'El cliente no existe';
    END IF;

    -- Validar rango de fechas
    IF fecha_fin < fecha_inicio THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'La fecha de fin no puede ser menor a la de inicio';
    END IF;

    -- Calcular total gastado por el cliente a partir de los detalles de ventas
    SELECT COALESCE(SUM(dv.cantidad * dv.precio_unitario), 0)
    INTO total
    FROM Ventas v
    JOIN Detalle_Ventas dv ON v.id_venta = dv.id_venta
    WHERE v.id_cliente = cliente_id
      AND DATE(v.fecha) BETWEEN fecha_inicio AND fecha_fin;

    RETURN total;
END //
DELIMITER ;


-- función 2: descuentoproducto
-- obtiene el descuento activo de un producto, valida producto y busca promociones vigentes.
DELIMITER //

CREATE FUNCTION descuentoproducto(
    producto_id INT
) RETURNS DECIMAL(5,2)
DETERMINISTIC
BEGIN
    DECLARE descuento DECIMAL(5,2);

    -- Validar existencia del producto
    IF NOT EXISTS (
        SELECT 1 FROM Productos WHERE id_producto = producto_id
    ) THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'El producto no existe';
    END IF;

    -- Buscar el mayor descuento vigente para el producto
    SELECT COALESCE(MAX(pr.descuento), 0)
    INTO descuento
    FROM Producto_Promocion pp
    JOIN Promociones pr ON pp.id_promocion = pr.id_promocion
    WHERE pp.id_producto = producto_id
      AND CURDATE() BETWEEN pr.fecha_inicio AND pr.fecha_fin;

    RETURN descuento;
END //

DELIMITER ;
drop function descuentoproducto

-- función 3: esadmin
-- verifica si un usuario es administrador, valida usuario y comprueba su rol.
delimiter //
create function esadmin(
    usuario_id int
) returns boolean
deterministic
begin
    declare admin boolean;
    
    if not exists (select 1 from usuarios where id_usuario = usuario_id) then
        signal sqlstate '45000' set message_text = 'usuario no existe';
    end if;

    select count(*) > 0
    into admin
    from usuarios u
    join roles r on u.id_rol = r.id_rol
    where u.id_usuario = usuario_id
      and r.nombre = 'administrador';

    return admin;
end //
delimiter ;

-- ejemplos de uso
-- función 1: totalventascliente
-- Total gastado por cliente 1 entre el 1 y el 31 de agosto de 2025
SELECT totalventascliente(1, '2025-08-01', '2025-08-31') AS total_gastado;

-- Totales para clientes 1, 2 y 3
SELECT 
    id_cliente,
    nombre,
    totalventascliente(id_cliente, '2025-08-01', '2025-08-31') AS total_gastado
FROM clientes
WHERE id_cliente IN (1, 2, 7);


-- Ver descuentos de varios productos
SELECT 
    p.id_producto,
    p.nombre,
    descuentoproducto(p.id_producto) AS descuento_actual
FROM productos p
WHERE p.id_producto IN (1, 2, 3);


-- función 3: esadmin
select esadmin(1) as es_administrador;

-- ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--
-- 1. Trigger de auditoría de actualizaciones en productos

DELIMITER $$

CREATE TRIGGER trg_auditoria_update_producto
AFTER UPDATE ON Productos
FOR EACH ROW
BEGIN
  INSERT INTO Log_Acciones (id_usuario, accion, tabla, id_afectado, fecha)
  VALUES (
    1, 
    'UPDATE',
    'Productos',
    NEW.id_producto,
    NOW()
  );
END$$

DELIMITER ;

--  2. Trigger para controlar el stock al registrar una venta
DELIMITER $$

CREATE TRIGGER trg_control_stock_venta
AFTER INSERT ON detalle_ventas
FOR EACH ROW
BEGIN
  DECLARE v_id_inventario INT;

  -- Seleccionar el inventario más reciente para el producto vendido
  SELECT id_inventario
  INTO v_id_inventario
  FROM inventario
  WHERE id_producto = NEW.id_producto
  ORDER BY fecha_entrada DESC
  LIMIT 1;

  -- Actualizar la cantidad en inventario
  UPDATE inventario
  SET cantidad = cantidad - NEW.cantidad
  WHERE id_inventario = v_id_inventario;

  -- Registrar la acción en log_acciones
  INSERT INTO log_acciones (id_usuario, accion, tabla, id_afectado, fecha)
  VALUES (
    2, 
    'venta_stock',
    'inventario',
    v_id_inventario,
    NOW()
  );
END$$

DELIMITER ;



-- 3. Trigger para registrar notificación de stock bajo

delimiter $$

create trigger trg_notificacion_stock_bajo
after update on inventario
for each row
begin
  if new.cantidad < 10 then
    insert into log_acciones (id_usuario, accion, tabla, id_afectado, fecha)
    values (
      3, -- id del usuario encargado de inventario
      'stock_bajo',
      'inventario',
      new.id_inventario,
      now()
    );
  end if;
end$$

delimiter ;

-- 1
-- Supongamos que el producto con ID 1 es 'Leche Entera 1L'
UPDATE productos 
SET precio = 1.80 
WHERE id_producto = 2;

SELECT * FROM Log_Acciones
WHERE tabla = 'Productos' AND accion = 'UPDATE'
ORDER BY fecha DESC;

-- 2
SELECT * FROM Inventario WHERE id_producto = 1 ORDER BY fecha_entrada DESC LIMIT 1;

INSERT INTO Ventas (id_cliente, fecha, total, id_usuario)
VALUES (1, NOW(), 5.00, 2);
SELECT * FROM ventas;
INSERT INTO Detalle_Ventas (id_venta, id_producto, cantidad, precio_unitario)
VALUES (51, 1, 2, 1.50);

-- Verifica que el Log_Acciones registró la actualización:
SELECT * FROM Log_Acciones WHERE tabla = 'Inventario' ORDER BY fecha DESC;

 -- 3. Verifica el valor actual antes del update
-- Por ejemplo, si quieres probar con el id_inventario = 1:

SELECT * FROM Inventario WHERE id_inventario = 1;
-- Supongamos que cantidad = 100.

-- 2. Realiza un UPDATE que dispare el trigger
-- Reduce la cantidad a un valor menor que 10, por ejemplo:


UPDATE Inventario
SET cantidad = 5
WHERE id_inventario = 1;

-- 3. Verifica que se insertó en Log_Acciones

SELECT * FROM Log_Acciones
WHERE accion = 'stock_bajo'
  AND tabla = 'inventario'
  AND id_afectado = 1
ORDER BY fecha DESC;

-- ////////////////////////////////////////////////////////////////////////////////////////////////////////////// --

-- 1. Asignar roles a usuarios 

-- Crear usuarios y asignar roles
CREATE USER 'oscar'@'localhost' IDENTIFIED BY '1234';
CREATE USER 'gabriel'@'localhost' IDENTIFIED BY '1234';
CREATE USER 'jhon'@'localhost' IDENTIFIED BY '1234';
CREATE USER 'oscar_visitante'@'localhost' IDENTIFIED BY '1234';

-- 2. Asignar privilegios a cada rol
-- admin_db: acceso total

GRANT ALL PRIVILEGES ON supermercadoProyecto.* TO 'oscar'@'localhost';

-- auditor_db: solo lectura, especialmente sobre logs, ventas, usuarios

GRANT SELECT ON supermercadoProyecto.Usuarios TO 'gabriel'@'localhost';
GRANT SELECT ON supermercadoProyecto.Ventas TO 'gabriel'@'localhost';
GRANT SELECT ON supermercadoProyecto.Detalle_Ventas TO 'gabriel'@'localhost';
GRANT SELECT ON supermercadoProyecto.Log_Acciones TO 'gabriel'@'localhost';

--  operador_db: gestión de productos, inventario, ventas

GRANT SELECT, INSERT, UPDATE ON supermercadoProyecto.Productos TO 'jhon'@'localhost';
GRANT SELECT, INSERT, UPDATE ON supermercadoProyecto.Inventario TO 'jhon'@'localhost';
GRANT SELECT, INSERT, UPDATE ON supermercadoProyecto.Ventas TO 'jhon'@'localhost';
GRANT SELECT, INSERT ON supermercadoProyecto.Detalle_Ventas TO 'jhon'@'localhost';

-- usuario_final: solo lectura básica

GRANT SELECT ON supermercadoProyecto.Productos TO 'oscar_visitante';
GRANT SELECT ON supermercadoProyecto.Categorias TO 'oscar_visitante';
GRANT SELECT ON supermercadoProyecto.Promociones TO 'oscar_visitante';


select user , host from mysql.user;
-- ///////////////////////////////////////////////////////////////////////////////////////////////////////////-- 
-- Índices simples 

CREATE INDEX idx_nombre_clientes
ON Clientes (nombre);

SELECT * FROM Clientes WHERE nombre = 'Ana Lopez Torres';

-- Índices compuestos

CREATE INDEX idx_venta_producto
ON Detalle_Ventas (id_venta, id_producto);

SELECT * FROM Detalle_Ventas
WHERE id_venta = 5 AND id_producto = 9;

-- /////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Encriptado
INSERT INTO Usuarios (nombre, contraseña, rol) VALUES
('administrador', SHA2('admin_db', 256), 'Administrador');

SELECT nombre, contraseña FROM Usuarios;

-- Desencriptado
SELECT nombre, CAST(SHA2(contraseña, 256) AS CHAR) AS contraseña_descifrada
FROM Usuarios;


-- //////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Consulta Segura
SELECT * FROM Usuarios
WHERE nombre = 'administrador' AND contraseña = SHA2('admin_db', 256);

-- Consulta Vulnerable
SELECT * FROM Usuarios
WHERE nombre = '' OR 1=1;


-- //////////////////////////////////////////////////////////////////////////////////////////////////////--
-- Mitigacion
DELIMITER $$

CREATE PROCEDURE login_seguro (
    IN p_usuario VARCHAR(50),
    IN p_contraseña VARCHAR(100)
)
BEGIN
    SELECT id_usuario, nombre
    FROM Usuarios
    WHERE nombre = p_usuario
    AND contraseña = SHA2(p_contraseña, 256);
END $$

DELIMITER ;

CALL login_seguro('administrador', 'admin_db');

-- Probar con intento de SQL Injection
CALL login_seguro("' OR 1=1 -- ", 'x');
-- Crear la base de datos
CREATE DATABASE supermercadoProyecto;
USE supermercadoProyecto;

-- Tabla: Categorias
CREATE TABLE Categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    descripcion TEXT,
    CHECK (nombre <> '')
);

-- Tabla: Proveedores
CREATE TABLE Proveedores (
    id_proveedor INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    contacto VARCHAR(100),
    telefono VARCHAR(20),
    CHECK (nombre <> '')
);

-- Tabla: Productos
CREATE TABLE Productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    id_categoria INT NOT NULL,
    fecha_vencimiento DATE,
    CHECK (precio >= 0),
    FOREIGN KEY (id_categoria) REFERENCES Categorias(id_categoria) ON DELETE CASCADE ON UPDATE CASCADE
);


-- Tabla: Producto_Proveedor (muchos a muchos)
CREATE TABLE Producto_Proveedor (
    id_producto INT NOT NULL,
    id_proveedor INT NOT NULL,
    PRIMARY KEY (id_producto, id_proveedor),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_proveedor) REFERENCES Proveedores(id_proveedor) ON DELETE CASCADE ON UPDATE CASCADE
);


-- Tabla: Clientes
CREATE TABLE Clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARBINARY(255),  -- Para guardar el correo cifrado
    telefono VARCHAR(20),
    es_frecuente BOOLEAN DEFAULT FALSE,
    CHECK (nombre <> '')
);

-- Tabla: Usuarios
CREATE TABLE Usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    contraseña VARCHAR(64) NOT NULL,
    rol VARCHAR(50) NOT NULL,
    CHECK (nombre <> '')
);

-- Tabla: Inventario
CREATE TABLE Inventario (
    id_inventario INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    fecha_entrada DATE NOT NULL,
    id_usuario INT NOT NULL,
    CHECK (cantidad >= 0),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Tabla: Ventas
CREATE TABLE Ventas (
    id_venta INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    fecha DATETIME NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    id_usuario INT NOT NULL,
    CHECK (total >= 0),
    FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE ON UPDATE CASCADE
);


-- Tabla: Detalle_Ventas
CREATE TABLE Detalle_Ventas (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_venta INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    CHECK (cantidad > 0),
    CHECK (precio_unitario >= 0),
    FOREIGN KEY (id_venta) REFERENCES Ventas(id_venta) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto) ON DELETE CASCADE ON UPDATE CASCADE
);



-- Tabla: Promociones
CREATE TABLE Promociones (
    id_promocion INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descuento DECIMAL(5,2) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    CHECK (descuento BETWEEN 0 AND 100),
    CHECK (fecha_fin >= fecha_inicio)
);

-- Tabla: Producto_Promocion (muchos a muchos)
CREATE TABLE Producto_Promocion (
    id_producto INT NOT NULL,
    id_promocion INT NOT NULL,
    PRIMARY KEY (id_producto, id_promocion),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_promocion) REFERENCES Promociones(id_promocion) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Tabla: Devoluciones
CREATE TABLE Devoluciones (
    id_devolucion INT AUTO_INCREMENT PRIMARY KEY,
    id_venta INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    motivo TEXT NOT NULL,
    fecha DATE NOT NULL,
    id_usuario INT NOT NULL,
    CHECK (cantidad > 0),
    FOREIGN KEY (id_venta) REFERENCES Ventas(id_venta) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Tabla: Log_Acciones
CREATE TABLE Log_Acciones (
    id_log INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    accion VARCHAR(50) NOT NULL,
    tabla VARCHAR(50) NOT NULL,
    id_afectado INT,
    fecha DATETIME NOT NULL,
    ip VARCHAR(45),
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Tabla: Categorias 
INSERT INTO Categorias (nombre, descripcion) VALUES
('Lacteos', 'Productos derivados de la leche y alternativas vegetales'),
('Carnes', 'Carnes frescas de res, pollo y cerdo'),
('Bebidas', 'Bebidas no alcoholicas y energizantes'),
('Panaderia', 'Panes frescos, pasteles y reposteria'),
('Frutas y Verduras', 'Frutas y verduras frescas de temporada'),
('Cereales', 'Cereales para desayuno y granos enteros'),
('Enlatados', 'Conservas y alimentos enlatados'),
('Limpieza', 'Productos de limpieza para hogar y ropa'),
('Cuidado Personal', 'Productos de higiene personal y cosmeticos'),
('Congelados', 'Alimentos congelados y precocidos'),
('Snacks', 'Aperitivos salados y golosinas'),
('Bebidas Alcoholicas', 'Vinos, cervezas y licores'),
('Pescados', 'Pescados y mariscos frescos'),
('Condimentos', 'Especias, salsas y condimentos'),
('Dulces', 'Chocolates, caramelos y postres'),
('Lacteos Veganos', 'Alternativas vegetales a lacteos'),
('Pan sin Gluten', 'Panes para dietas especiales'),
('Bebidas Energeticas', 'Bebidas energizantes y deportivas'),
('Mascotas', 'Alimentos y accesorios para mascotas'),
('Hogar', 'Articulos para el hogar como toallas y utensilios'),
('Frutos Secos', 'Nueces, almendras y semillas'),
('Pastas', 'Pastas alimenticias secas y frescas'),
('Aceites', 'Aceites comestibles para cocina'),
('Salsas', 'Salsas y aderezos para comidas'),
('Postres', 'Postres preparados y listos para consumir');

-- Tabla: Proveedores
INSERT INTO Proveedores (nombre, contacto, telefono) VALUES
('Lacteos del Valle', 'Juan Perez', '+593-9-98765401'),
('Carnes Premium', 'Maria Gomez', '+593-9-98765402'),
('Bebidas Frescas', 'Carlos Lopez', '+593-9-98765403'),
('Panaderia La Estrella', 'Ana Ruiz', '+593-9-98765404'),
('Frutas del Campo', 'Luis Martinez', '+593-9-98765405'),
('Cereales Salud', 'Sofia Diaz', '+593-9-98765406'),
('Enlatados Global', 'Pedro Sanchez', '+593-9-98765407'),
('Limpieza Total', 'Laura Fernandez', '+593-9-98765408'),
('Cuidado Plus', 'Diego Torres', '+593-9-98765409'),
('Congelados Frio', 'Clara Morales', '+593-9-98765410'),
('Snacks Sabrosos', 'Javier Romero', '+593-9-98765411'),
('Bebidas Premium', 'Elena Castro', '+593-9-98765412'),
('Pescados del Mar', 'Miguel Vargas', '+593-9-98765413'),
('Condimentos Rico', 'Paula Herrera', '+593-9-98765414'),
('Dulces Delicia', 'Andres Mendoza', '+593-9-98765415'),
('Veganos Natural', 'Lucia Ortiz', '+593-9-98765416'),
('Pan Especial', 'Roberto Silva', '+593-9-98765417'),
('Energia Total', 'Carmen Ramirez', '+593-9-98765418'),
('Mascotas Felices', 'Gabriel Luna', '+593-9-98765419'),
('Hogar Practico', 'Valeria Rojas', '+593-9-98765420'),
('Frutos Secos SA', 'Daniel Cruz', '+593-9-98765421'),
('Pastas Italia', 'Marina Flores', '+593-9-98765422'),
('Aceites Puro', 'Hector Gomez', '+593-9-98765423'),
('Salsas Sabores', 'Natalia Vega', '+593-9-98765424'),
('Postres Dulces', 'Felipe Castro', '+593-9-98765425');


-- Tabla: Usuarios
INSERT INTO Usuarios (nombre, contraseña, rol) VALUES
('administrador', SHA2('admin_db', 256), 'Administrador'),
('auditor_db', SHA2('auditor_db', 256), 'Auditor'),
('operador_db', SHA2('operador_db', 256), 'Operador'),
('usuario_final', SHA2('usuario_final', 256), 'Visitante');

-- Tabla: Productos 
INSERT INTO Productos (nombre, precio, id_categoria, fecha_vencimiento) VALUES
('Leche Entera 1L', 1.50, 1, '2025-12-01'),
('Leche Descremada 1L', 1.60, 1, '2025-12-15'),
('Carne de Res 1kg', 5.50, 2, NULL),
('Pollo Entero 1.5kg', 4.00, 2, NULL),
('Agua Mineral 1.5L', 0.80, 3, '2026-06-01'),
('Jugo de Naranja 1L', 2.50, 3, '2025-11-01'),
('Pan Integral 500g', 2.00, 4, '2025-08-10'),
('Croissant 100g', 1.20, 4, '2025-08-05'),
('Manzana Roja 1kg', 1.20, 5, '2025-09-01'),
('Brocoli 500g', 1.50, 5, '2025-08-20'),
('Cereal Maiz 500g', 3.50, 6, '2026-03-01'),
('Avena Integral 1kg', 2.80, 6, '2026-05-01'),
('Atun Enlatado 170g', 1.80, 7, '2027-01-01'),
('Frijoles Enlatados 400g', 1.40, 7, '2027-02-01'),
('Detergente Liquido 1L', 2.50, 8, NULL),
('Jabon Liquido 500ml', 1.90, 8, NULL),
('Shampoo Anticaspa 400ml', 4.00, 9, '2026-12-01'),
('Pasta Dental 100ml', 2.20, 9, '2026-10-01'),
('Pizza Congelada 400g', 6.50, 10, '2026-02-01'),
('Helado Vainilla 1L', 5.00, 10, '2026-03-01'),
('Papas Fritas 200g', 1.90, 11, '2025-11-01'),
('Chocolates 100g', 2.20, 15, '2026-04-01'),
('Leche de Almendra 1L', 3.00, 16, '2026-01-01'),
('Pan sin Gluten 400g', 3.50, 17, '2025-08-20'),
('Bebida Energetica 500ml', 2.80, 18, '2026-05-01'),
('Yogurt Natural 500ml', 2.00, 1, '2025-12-20'),
('Queso Fresco 500g', 3.50, 1, '2025-11-15'),
('Carne Molida 1kg', 5.00, 2, NULL),
('Pechuga de Pollo 1kg', 4.50, 2, NULL),
('Agua con Gas 1.5L', 1.00, 3, '2026-07-01'),
('Jugo de Manzana 1L', 2.70, 3, '2025-11-15'),
('Pan de Molde 600g', 2.50, 4, '2025-08-12'),
('Baguette 300g', 1.50, 4, '2025-08-07'),
('Banano 1kg', 1.00, 5, '2025-09-10'),
('Zanahoria 500g', 1.20, 5, '2025-08-25'),
('Cereal de Trigo 500g', 3.80, 6, '2026-04-01'),
('Quinoa 1kg', 4.00, 6, '2026-06-01'),
('Maiz Enlatado 400g', 1.50, 7, '2027-03-01'),
('Sardinas Enlatadas 170g', 1.90, 7, '2027-04-01'),
('Suavizante Ropa 1L', 2.80, 8, NULL),
('Desinfectante 500ml', 2.00, 8, NULL),
('Acondicionador 400ml', 4.20, 9, '2026-11-01'),
('Crema Dental 150ml', 2.50, 9, '2026-09-01'),
('Nuggets Congelados 500g', 5.50, 10, '2026-01-15'),
('Helado Chocolate 1L', 5.20, 10, '2026-02-15'),
('Nachos 200g', 2.00, 11, '2025-12-01'),
('Caramelos 100g', 1.80, 15, '2026-03-01'),
('Leche de Soya 1L', 2.90, 16, '2026-02-01'),
('Pan sin Gluten 500g', 3.80, 17, '2025-08-25'),
('Bebida Isotonica 500ml', 2.50, 18, '2026-06-01');

-- Tabla: Producto_Proveedor
INSERT INTO Producto_Proveedor (id_producto, id_proveedor) VALUES
(1, 1), (2, 1), (3, 2), (4, 2), (5, 3),
(6, 3), (7, 4), (8, 4), (9, 5), (10, 5),
(11, 6), (12, 6), (13, 7), (14, 7), (15, 8),
(16, 8), (17, 9), (18, 9), (19, 10), (20, 10),
(21, 11), (22, 15), (23, 16), (24, 17), (25, 18),
(26, 19), (27, 20), (28, 21), (29, 22), (30, 23),
(31, 24), (32, 25), (33, 1), (34, 2), (35, 3),
(36, 4), (37, 5), (38, 6), (39, 7), (40, 8),
(41, 9), (42, 10), (43, 11), (44, 12), (45, 13),
(46, 14), (47, 15), (48, 16), (49, 17), (50, 18);


INSERT INTO Clientes (nombre, email, telefono, es_frecuente) VALUES
('Ana Lopez Torres', AES_ENCRYPT('ana.lopez@gmail.com', 'clave123'), '+593-9-98765401', TRUE),
('Carlos Ruiz Gomez', AES_ENCRYPT('carlos.ruiz@gmail.com', 'clave123'), '+593-9-98765402', FALSE),
('Maria Gomez Salazar', AES_ENCRYPT('maria.gomez@gmail.com', 'clave123'), '+593-9-98765403', TRUE),
('Juan Perez Vargas', AES_ENCRYPT('juan.perez@gmail.com', 'clave123'), '+593-9-98765404', FALSE),
('Laura Martinez Diaz', AES_ENCRYPT('laura.martinez@gmail.com', 'clave123'), '+593-9-98765405', TRUE),
('Diego Torres Morales', AES_ENCRYPT('diego.torres@gmail.com', 'clave123'), '+593-9-98765406', FALSE),
('Sofia Diaz Romero', AES_ENCRYPT('sofia.diaz@gmail.com', 'clave123'), '+593-9-98765407', TRUE),
('Pedro Sanchez Castro', AES_ENCRYPT('pedro.sanchez@gmail.com', 'clave123'), '+593-9-98765408', FALSE),
('Clara Morales Ortiz', AES_ENCRYPT('clara.morales@gmail.com', 'clave123'), '+593-9-98765409', TRUE),
('Javier Romero Silva', AES_ENCRYPT('javier.romero@gmail.com', 'clave123'), '+593-9-98765410', FALSE),
('Elena Castro Ramirez', AES_ENCRYPT('elena.castro@gmail.com', 'clave123'), '+593-9-98765411', TRUE),
('Miguel Vargas Luna', AES_ENCRYPT('miguel.vargas@gmail.com', 'clave123'), '+593-9-98765412', FALSE),
('Paula Herrera Rojas', AES_ENCRYPT('paula.herrera@gmail.com', 'clave123'), '+593-9-98765413', TRUE),
('Andres Mendoza Cruz', AES_ENCRYPT('andres.mendoza@gmail.com', 'clave123'), '+593-9-98765414', FALSE),
('Lucia Ortiz Flores', AES_ENCRYPT('lucia.ortiz@gmail.com', 'clave123'), '+593-9-98765415', TRUE),
('Roberto Silva Gomez', AES_ENCRYPT('roberto.silva@gmail.com', 'clave123'), '+593-9-98765416', FALSE),
('Carmen Ramirez Vega', AES_ENCRYPT('carmen.ramirez@gmail.com', 'clave123'), '+593-9-98765417', TRUE),
('Gabriel Luna Castro', AES_ENCRYPT('gabriel.luna@gmail.com', 'clave123'), '+593-9-98765418', FALSE),
('Valeria Rojas Perez', AES_ENCRYPT('valeria.rojas@gmail.com', 'clave123'), '+593-9-98765419', TRUE),
('Daniel Cruz Martinez', AES_ENCRYPT('daniel.cruz@gmail.com', 'clave123'), '+593-9-98765420', FALSE),
('Marina Flores Torres', AES_ENCRYPT('marina.flores@gmail.com', 'clave123'), '+593-9-98765421', TRUE),
('Hector Gomez Salazar', AES_ENCRYPT('hector.gomez@gmail.com', 'clave123'), '+593-9-98765422', FALSE),
('Natalia Vega Diaz', AES_ENCRYPT('natalia.vega@gmail.com', 'clave123'), '+593-9-98765423', TRUE),
('Felipe Castro Ruiz', AES_ENCRYPT('felipe.castro@gmail.com', 'clave123'), '+593-9-98765424', FALSE),
('Santiago Rivas Morales', AES_ENCRYPT('santiago.rivas@gmail.com', 'clave123'), '+593-9-98765425', TRUE),
('Camila Torres Lopez', AES_ENCRYPT('camila.torres@gmail.com', 'clave123'), '+593-9-98765426', TRUE),
('Lucas Gomez Ruiz', AES_ENCRYPT('lucas.gomez@gmail.com', 'clave123'), '+593-9-98765427', FALSE),
('Valentina Salazar Diaz', AES_ENCRYPT('valentina.salazar@gmail.com', 'clave123'), '+593-9-98765428', TRUE),
('Mateo Vargas Perez', AES_ENCRYPT('mateo.vargas@gmail.com', 'clave123'), '+593-9-98765429', FALSE),
('Isabella Diaz Martinez', AES_ENCRYPT('isabella.diaz@gmail.com', 'clave123'), '+593-9-98765430', TRUE),
('Santiago Morales Torres', AES_ENCRYPT('santiago.morales@gmail.com', 'clave123'), '+593-9-98765431', FALSE),
('Emma Romero Diaz', AES_ENCRYPT('emma.romero@gmail.com', 'clave123'), '+593-9-98765432', TRUE),
('Tomas Castro Sanchez', AES_ENCRYPT('tomas.castro@gmail.com', 'clave123'), '+593-9-98765433', FALSE),
('Sofia Ortiz Morales', AES_ENCRYPT('sofia.ortiz2@gmail.com', 'clave123'), '+593-9-98765434', TRUE),
('Benjamin Silva Romero', AES_ENCRYPT('benjamin.silva@gmail.com', 'clave123'), '+593-9-98765435', FALSE),
('Mia Castro Ramirez', AES_ENCRYPT('mia.castro@gmail.com', 'clave123'), '+593-9-98765436', TRUE),
('Sebastian Luna Vargas', AES_ENCRYPT('sebastian.luna@gmail.com', 'clave123'), '+593-9-98765437', FALSE),
('Lucia Rojas Herrera', AES_ENCRYPT('lucia.rojas@gmail.com', 'clave123'), '+593-9-98765438', TRUE),
('Martin Cruz Mendoza', AES_ENCRYPT('martin.cruz@gmail.com', 'clave123'), '+593-9-98765439', FALSE),
('Julieta Flores Ortiz', AES_ENCRYPT('julieta.flores@gmail.com', 'clave123'), '+593-9-98765440', TRUE),
('Nicolas Gomez Silva', AES_ENCRYPT('nicolas.gomez@gmail.com', 'clave123'), '+593-9-98765441', FALSE),
('Catalina Vega Ramirez', AES_ENCRYPT('catalina.vega@gmail.com', 'clave123'), '+593-9-98765442', TRUE),
('Juan Luna Castro', AES_ENCRYPT('juan.luna@gmail.com', 'clave123'), '+593-9-98765443', FALSE),
('Valeria Perez Rojas', AES_ENCRYPT('valeria.perez2@gmail.com', 'clave123'), '+593-9-98765444', TRUE),
('Diego Martinez Cruz', AES_ENCRYPT('diego.martinez2@gmail.com', 'clave123'), '+593-9-98765445', FALSE),
('Martina Torres Flores', AES_ENCRYPT('martina.torres@gmail.com', 'clave123'), '+593-9-98765446', TRUE),
('Joaquin Salazar Gomez', AES_ENCRYPT('joaquin.salazar@gmail.com', 'clave123'), '+593-9-98765447', FALSE),
('Clara Diaz Vega', AES_ENCRYPT('clara.diaz@gmail.com', 'clave123'), '+593-9-98765448', TRUE),
('Emiliano Ruiz Castro', AES_ENCRYPT('emiliano.ruiz@gmail.com', 'clave123'), '+593-9-98765449', FALSE),
('Antonia Morales Rivas', AES_ENCRYPT('antonia.morales@gmail.com', 'clave123'), '+593-9-98765450', TRUE);

-- Tabla: Inventario 
INSERT INTO Inventario (id_producto, cantidad, fecha_entrada, id_usuario) VALUES
(1, 100, '2025-07-01', 3), (2, 80, '2025-07-02', 3), (3, 50, '2025-07-03', 3),
(4, 60, '2025-07-04', 3), (5, 200, '2025-07-05', 3), (6, 120, '2025-07-06', 3),
(7, 90, '2025-07-07', 3), (8, 150, '2025-07-08', 3), (9, 140, '2025-07-09', 3),
(10, 110, '2025-07-10', 3), (11, 130, '2025-07-11', 3), (12, 100, '2025-07-12', 3),
(13, 80, '2025-07-13', 3), (14, 90, '2025-07-14', 3), (15, 70, '2025-07-15', 3),
(16, 60, '2025-07-16', 3), (17, 50, '2025-07-17', 3), (18, 40, '2025-07-18', 3),
(19, 30, '2025-07-19', 3), (20, 25, '2025-07-20', 3), (21, 200, '2025-07-21', 3),
(22, 180, '2025-07-22', 3), (23, 100, '2025-07-23', 3), (24, 70, '2025-07-24', 3),
(25, 90, '2025-07-25', 3),
(26, 120, '2025-07-26', 3), (27, 100, '2025-07-27', 3), (28, 60, '2025-07-28', 3),
(29, 70, '2025-07-29', 3), (30, 180, '2025-07-30', 3), (31, 130, '2025-07-31', 3),
(32, 100, '2025-08-01', 3), (33, 140, '2025-08-02', 3), (34, 150, '2025-08-03', 3),
(35, 110, '2025-08-04', 3), (36, 120, '2025-08-05', 3), (37, 100, '2025-08-06', 3),
(38, 80, '2025-08-07', 3), (39, 90, '2025-08-08', 3), (40, 70, '2025-08-09', 3),
(41, 60, '2025-08-10', 3), (42, 50, '2025-08-11', 3), (43, 40, '2025-08-12', 3),
(44, 30, '2025-08-13', 3), (45, 25, '2025-08-14', 3), (46, 200, '2025-08-15', 3),
(47, 180, '2025-08-16', 3), (48, 100, '2025-08-17', 3), (49, 70, '2025-08-18', 3),
(50, 90, '2025-08-19', 3);


-- Tabla: Ventas 
INSERT INTO Ventas (id_cliente, fecha, total, id_usuario) VALUES
(1, '2025-08-01 09:00:00', 15.50, 2), (2, '2025-08-01 09:30:00', 8.00, 2),
(3, '2025-08-01 10:00:00', 20.00, 2), (4, '2025-08-01 10:30:00', 12.50, 2),
(5, '2025-08-01 11:00:00', 30.00, 2), (6, '2025-08-01 11:30:00', 7.80, 2),
(7, '2025-08-01 12:00:00', 18.90, 2), (8, '2025-08-01 12:30:00', 25.00, 2),
(9, '2025-08-01 13:00:00', 14.40, 2), (10, '2025-08-01 13:30:00', 22.50, 2),
(11, '2025-08-01 14:00:00', 16.70, 2), (12, '2025-08-01 14:30:00', 9.00, 2),
(13, '2025-08-01 15:00:00', 28.00, 2), (14, '2025-08-01 15:30:00', 11.20, 2),
(15, '2025-08-01 16:00:00', 19.50, 2), (16, '2025-08-01 16:30:00', 13.80, 2),
(17, '2025-08-01 17:00:00', 21.00, 2), (18, '2025-08-01 17:30:00', 10.50, 2),
(19, '2025-08-01 18:00:00', 17.90, 2), (20, '2025-08-01 18:30:00', 24.00, 2),
(21, '2025-08-01 19:00:00', 15.30, 2), (22, '2025-08-01 19:30:00', 8.50, 2),
(23, '2025-08-01 20:00:00', 26.00, 2), (24, '2025-08-01 20:30:00', 12.00, 2),
(25, '2025-08-01 21:00:00', 18.00, 2),
(26, '2025-08-02 09:00:00', 10.00, 2),
(27, '2025-08-02 09:30:00', 12.50, 2),
(28, '2025-08-02 10:00:00', 15.00, 2),
(29, '2025-08-02 10:30:00', 8.50, 2),
(30, '2025-08-02 11:00:00', 20.00, 2),
(31, '2025-08-02 11:30:00', 14.20, 2),
(32, '2025-08-02 12:00:00', 17.90, 2),
(33, '2025-08-02 12:30:00', 22.00, 2),
(34, '2025-08-02 13:00:00', 11.50, 2),
(35, '2025-08-02 13:30:00', 16.80, 2),
(36, '2025-08-02 14:00:00', 13.00, 2),
(37, '2025-08-02 14:30:00', 19.50, 2),
(38, '2025-08-02 15:00:00', 25.00, 2),
(39, '2025-08-02 15:30:00', 9.00, 2),
(40, '2025-08-02 16:00:00', 12.70, 2),
(41, '2025-08-02 16:30:00', 18.40, 2),
(42, '2025-08-02 17:00:00', 14.60, 2),
(43, '2025-08-02 17:30:00', 21.20, 2),
(44, '2025-08-02 18:00:00', 16.90, 2),
(45, '2025-08-02 18:30:00', 10.30, 2),
(46, '2025-08-02 19:00:00', 23.50, 2),
(47, '2025-08-02 19:30:00', 13.80, 2),
(48, '2025-08-02 20:00:00', 17.00, 2),
(49, '2025-08-02 20:30:00', 11.40, 2),
(50, '2025-08-02 21:00:00', 15.60, 2);

-- Tabla: Detalle_Ventas 
INSERT INTO Detalle_Ventas (id_venta, id_producto, cantidad, precio_unitario) VALUES
(1, 1, 2, 1.50), (2, 5, 3, 0.80), (3, 3, 1, 5.50), (4, 7, 2, 2.00),
(5, 9, 3, 1.20), (6, 11, 1, 3.50), (7, 13, 2, 1.80), (8, 15, 1, 2.50),
(9, 17, 1, 4.00), (10, 19, 1, 6.50), (11, 21, 2, 1.90), (12, 22, 1, 2.20),
(13, 23, 1, 3.00), (14, 24, 2, 3.50), (15, 25, 3, 2.80), (16, 1, 1, 1.50),
(17, 3, 1, 5.50), (18, 5, 2, 0.80), (19, 7, 1, 2.00), (20, 9, 2, 1.20),
(21, 11, 1, 3.50), (22, 13, 2, 1.80), (23, 15, 1, 2.50), (24, 17, 2, 4.00),
(25, 19, 1, 6.50),
(26, 26, 2, 2.00), (27, 27, 1, 3.50), (28, 28, 1, 5.00), (29, 29, 2, 4.50),
(30, 30, 3, 1.00), (31, 31, 2, 2.70), (32, 32, 1, 2.50), (33, 33, 2, 1.50),
(34, 34, 3, 1.00), (35, 35, 2, 1.20), (36, 36, 1, 3.80), (37, 37, 1, 4.00),
(38, 38, 2, 1.50), (39, 39, 2, 1.90), (40, 40, 1, 2.80), (41, 41, 1, 2.00),
(42, 42, 1, 4.20), (43, 43, 1, 2.50), (44, 44, 1, 5.50), (45, 45, 1, 5.20),
(46, 46, 2, 2.00), (47, 47, 1, 1.80), (48, 48, 1, 2.90), (49, 49, 1, 3.80),
(50, 50, 2, 2.50);

-- Tabla: Promociones
INSERT INTO Promociones (nombre, descuento, fecha_inicio, fecha_fin) VALUES
('Descuento Lacteos 10%', 10.00, '2025-08-01', '2025-08-15'),
('Oferta Carnes 15%', 15.00, '2025-08-02', '2025-08-16'),
('Promo Bebidas 20%', 20.00, '2025-08-03', '2025-08-17'),
('Panaderia 2x1', 50.00, '2025-08-04', '2025-08-18'),
('Frutas Frescas 10%', 10.00, '2025-08-05', '2025-08-19'),
('Cereales Saludables 15%', 15.00, '2025-08-06', '2025-08-20'),
('Enlatados Oferta 20%', 20.00, '2025-08-07', '2025-08-21'),
('Limpieza Total 25%', 25.00, '2025-08-08', '2025-08-22'),
('Cuidado Personal 10%', 10.00, '2025-08-09', '2025-08-23'),
('Congelados Baratos 15%', 15.00, '2025-08-10', '2025-08-24'),
('Snacks Promo 20%', 20.00, '2025-08-11', '2025-08-25'),
('Vino Especial 30%', 30.00, '2025-08-12', '2025-08-26'),
('Pescados Frescos 15%', 15.00, '2025-08-13', '2025-08-27'),
('Condimentos Oferta 10%', 10.00, '2025-08-14', '2025-08-28'),
('Dulces Baratos 20%', 20.00, '2025-08-15', '2025-08-29'),
('Veganos Descuento 15%', 15.00, '2025-08-16', '2025-08-30'),
('Pan sin Gluten 25%', 25.00, '2025-08-17', '2025-08-31'),
('Energia Total 20%', 20.00, '2025-08-18', '2025-09-01'),
('Mascotas Promo 10%', 10.00, '2025-08-19', '2025-09-02'),
('Hogar Oferta 15%', 15.00, '2025-08-20', '2025-09-03'),
('Frutos Secos 20%', 20.00, '2025-08-21', '2025-09-04'),
('Pastas Baratas 10%', 10.00, '2025-08-22', '2025-09-05'),
('Aceites Oferta 15%', 15.00, '2025-08-23', '2025-09-06'),
('Salsas Promo 20%', 20.00, '2025-08-24', '2025-09-07'),
('Postres Dulces 25%', 25.00, '2025-08-25', '2025-09-08'),
('Descuento Yogurt 15%', 15.00, '2025-08-26', '2025-09-09'),
('Oferta Queso 10%', 10.00, '2025-08-27', '2025-09-10'),
('Promo Carnes 20%', 20.00, '2025-08-28', '2025-09-11'),
('Bebidas Gas 25%', 25.00, '2025-08-29', '2025-09-12'),
('Pan Oferta 15%', 15.00, '2025-08-30', '2025-09-13'),
('Frutas 20%', 20.00, '2025-08-31', '2025-09-14'),
('Cereales Promo 10%', 10.00, '2025-09-01', '2025-09-15'),
('Enlatados 15%', 15.00, '2025-09-02', '2025-09-16'),
('Limpieza 20%', 20.00, '2025-09-03', '2025-09-17'),
('Cuidado Personal 25%', 25.00, '2025-09-04', '2025-09-18');

-- Tabla: Producto_Promocion
INSERT INTO Producto_Promocion (id_producto, id_promocion) VALUES
(1, 1), (2, 1), (3, 2), (4, 2), (5, 3),
(6, 3), (7, 4), (8, 4), (9, 5), (10, 5),
(11, 6), (12, 6), (13, 7), (14, 7), (15, 8),
(16, 8), (17, 9), (18, 9), (19, 10), (20, 10),
(21, 11), (22, 15), (23, 16), (24, 17), (25, 18),
(26, 26), (27, 27), (28, 28), (29, 28), (30, 29),
(31, 29), (32, 30), (33, 30), (34, 31), (35, 31);

-- Tabla: Devoluciones 
INSERT INTO Devoluciones (id_venta, id_producto, cantidad, motivo, fecha, id_usuario) VALUES
(1, 1, 1, 'Envase danado durante transporte', '2025-08-02', 1),
(2, 5, 2, 'Fecha de vencimiento proxima', '2025-08-02', 1),
(3, 3, 1, 'Error en la seleccion del producto', '2025-08-02', 1),
(4, 7, 1, 'Producto no deseado por el cliente', '2025-08-02', 1),
(5, 9, 2, 'Producto defectuoso al abrir', '2025-08-02', 1),
(6, 11, 1, 'Cambio de opinion del cliente', '2025-08-02', 1),
(7, 13, 1, 'Envase roto al recibir', '2025-08-02', 1),
(8, 15, 1, 'Error en el pedido enviado', '2025-08-02', 1),
(9, 17, 1, 'No conforme con la calidad', '2025-08-02', 1),
(10, 19, 1, 'Producto danado en tienda', '2025-08-02', 2),
(11, 21, 2, 'Fecha de vencimiento proxima', '2025-08-02', 2),
(12, 22, 1, 'Cambio de opinion del cliente', '2025-08-02', 2),
(13, 23, 1, 'Producto defectuoso', '2025-08-02', 2),
(14, 24, 2, 'Error en la seleccion', '2025-08-02', 2),
(15, 25, 1, 'No deseado por el cliente', '2025-08-02', 2),
(16, 1, 1, 'Envase danado', '2025-08-02', 2),
(17, 3, 1, 'Producto defectuoso', '2025-08-02', 3),
(18, 5, 2, 'Fecha de vencimiento proxima', '2025-08-02', 3),
(19, 7, 1, 'Error en el pedido', '2025-08-02', 3),
(20, 9, 2, 'No conforme con calidad', '2025-08-02', 3),
(21, 11, 1, 'Cambio de opinion', '2025-08-02', 3),
(22, 13, 2, 'Envase roto', '2025-08-02', 1),
(23, 15, 1, 'Error en la seleccion', '2025-08-02', 1),
(24, 17, 2, 'Producto defectuoso', '2025-08-02', 1),
(25, 19, 1, 'No deseado por el cliente', '2025-08-02', 1),
(26, 26, 1, 'Envase danado', '2025-08-03', 1),
(27, 27, 1, 'Producto defectuoso', '2025-08-03', 1),
(28, 28, 1, 'Error en la seleccion', '2025-08-03', 1),
(29, 29, 1, 'No deseado por el cliente', '2025-08-03', 1),
(30, 30, 2, 'Fecha de vencimiento proxima', '2025-08-03', 1);

-- Tabla: Log_Acciones 
INSERT INTO Log_Acciones (id_usuario, accion, tabla, id_afectado, fecha) VALUES
(1, 'INSERT', 'Productos', 1, '2025-08-01 08:00:00'),
(2, 'INSERT', 'Ventas', 1, '2025-08-01 09:00:00'),
(3, 'UPDATE', 'Inventario', 1, '2025-08-01 10:00:00'),
(4, 'SELECT', 'Ventas', NULL, '2025-08-01 11:00:00'),
(1, 'INSERT', 'Promociones', 1, '2025-08-01 12:00:00'),
(1, 'INSERT', 'Clientes', 1, '2025-08-01 13:00:00'),
(1, 'SELECT', 'Log_Acciones', NULL, '2025-08-01 14:00:00'),
(1, 'INSERT', 'Producto_Promocion', 1, '2025-08-01 15:00:00'),
(2, 'UPDATE', 'Inventario', 2, '2025-08-01 16:00:00'),
(3, 'INSERT', 'Detalle_Ventas', 1, '2025-08-01 17:00:00'),
(4, 'INSERT', 'Devoluciones', 1, '2025-08-01 18:00:00'),
(4, 'SELECT', 'Ventas', NULL, '2025-08-01 19:00:00'),
(2, 'INSERT', 'Producto_Proveedor', 1, '2025-08-01 20:00:00'),
(1, 'UPDATE', 'Usuarios', 1, '2025-08-01 21:00:00'),
(4, 'UPDATE', 'Inventario', 3, '2025-08-01 22:00:00'),
(2, 'INSERT', 'Productos', 2, '2025-08-02 08:00:00'),
(2, 'INSERT', 'Promociones', 2, '2025-08-02 09:00:00'),
(2, 'INSERT', 'Clientes', 2, '2025-08-02 10:00:00'),
(2, 'SELECT', 'Ventas', NULL, '2025-08-02 11:00:00'),
(2, 'INSERT', 'Detalle_Ventas', 2, '2025-08-02 12:00:00'),
(2, 'SELECT', 'Log_Acciones', NULL, '2025-08-02 13:00:00'),
(1, 'INSERT', 'Devoluciones', 2, '2025-08-02 14:00:00'),
(3, 'UPDATE', 'Productos', 3, '2025-08-02 15:00:00'),
(2, 'INSERT', 'Promociones', 3, '2025-08-02 16:00:00'),
(1, 'SELECT', 'Clientes', NULL, '2025-08-02 17:00:00');













use supermercadoproyecto;

SELECT * FROM categorias;
SELECT * FROM productos;
SELECT * FROM promociones;

INSERT INTO Detalle_Ventas (id_venta, id_producto, cantidad, precio_unitario) VALUES
(51, 50, 2, 2.50);

drop table Detalle_Ventas;

CREATE TABLE Clientes2 (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    telefono VARCHAR(20),
    es_frecuente BOOLEAN DEFAULT FALSE,
    CHECK (nombre <> '')
);